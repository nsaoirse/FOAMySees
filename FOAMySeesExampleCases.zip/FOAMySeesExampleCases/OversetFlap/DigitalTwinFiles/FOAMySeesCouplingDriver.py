import os
import concurrent.futures
import logging
import queue
import random
import subprocess
import time
from subprocess import Popen, DEVNULL
import pandas as pd
import re, csv
import matplotlib
import argparse
import numpy as np
import configuration_file as config
import buildOpenSeesModelInThisFile as userModel
import precice
import math as m

from scipy.spatial import KDTree
from precice import *
import copy
import vtk
from vtk.util.numpy_support import vtk_to_numpy

import sys
sys.path.insert(0, './FOAMySees')
import math

import meshio
import pyvista as pv

import openseespy.opensees as ops
from openseespy.opensees import *

from mpi4py import MPI

from FOAMySeesObjects import *
# #import openseespy.postprocessing.ops_vis as opsv


		
#########################################################################################
		
rank = MPI.COMM_WORLD.Get_rank()

OpenSees_dt=config.SolutionDT

if  rank == 0:
	print('SEES DT=',config.SolutionDT)
	print("Starting Structure Solver...")

numproc=ops.getNP()
	
parser = argparse.ArgumentParser()
parser.add_argument("configurationFileName", help="Name of the xml config file.", nargs='?', type=str,
					default="precice-config.xml")

try:
	args = parser.parse_args()
except SystemExit:
	if rank== 0:
		print("")
		print("Did you forget adding the precice configuration file as an argument?")
		print("Try '$ python Solid1Solver.py precice-config.xml'")
		quit()
		
tOUT=0

FOAMySees=FOAMySeesInstance(OpenSees_dt,config)
	
configFileName = args.configurationFileName

if __name__ == '__main__':# and rank==0:
	solverName = "FOAMySeesCouplingDriver"   
	N = len(FOAMySees.coupledNodes) # number of ops.nodes
	if rank== 0:
		print("N: " + str(N))

		print("Configure preCICE...")

		interface = precice.Interface(solverName, configFileName, 0, 1)
	
		print("preCICE configured...")

		dimensions = interface.get_dimensions()
		dimensions=3
		isSurfLoaded=0
		while isSurfLoaded==0:
			try:
				#Using PyVista to Read STL or OBJ containing points of Coupling Surface for CFD Mesh 
				# Branches = pv.read("FluidCouplingSurface.obj").points
				
				#Using PyVista to Calculate Cell Centers of faces 
				Branches= pv.read("FluidCouplingSurface.obj").cell_centers().points
				isSurfLoaded=1
			except: 
				isSurfLoaded=0
			  
		# using SciPy to calculate the K-means clustering  
			#   .... from scipy.spatial import KDTree
		Tree=KDTree(FOAMySees.nodeLocs)

		BranchToNodeRelationships=Tree.query(Branches)[1]


		CellToNodeRelationships=Tree.query(Branches)[1]		
		
	
		# Below was changed 7/26/23 from Branches to Cells 				
		verticesDisplacement=Branches
		verticesForce=Branches
		
		verticesDisplacement=np.array(verticesDisplacement)
		verticesForce=np.array(verticesForce)
		FOAMySees.verticesDisplacement=verticesDisplacement
		FOAMySees.verticesForce=verticesForce
		
		BranchTransform=np.zeros(np.shape(verticesDisplacement))
		Displacement = np.zeros(np.shape(verticesDisplacement))	

		Forces = np.zeros(np.shape(verticesForce))
		
		FOAMySees.moment = np.zeros([len(FOAMySees.coupledNodes),3])

		NodeToBranchNodeRelationships=[]
		NodeToCellFaceCenterRelationships=[]
				
		for n in range(len(FOAMySees.nodeLocs)):
			NodeToCellFaceCenterRelationships.append([n])
		
		for node in range(len(CellToNodeRelationships)):
			NodeToCellFaceCenterRelationships[CellToNodeRelationships[node]].append(node)		
		
		for n in range(len(FOAMySees.nodeLocs)):
			NodeToBranchNodeRelationships.append([n])

		for node in range(len(BranchToNodeRelationships)):
			NodeToBranchNodeRelationships[BranchToNodeRelationships[node]].append(node)
			
		FOAMySees.NodeToBranchNodeRelationships=NodeToBranchNodeRelationships
		FOAMySees.NodeToCellFaceCenterRelationships=NodeToCellFaceCenterRelationships		
		
		
		with open('BranchesLOCS.log', 'a+') as f:
			f.seek(0)
			f.truncate()
			print(NodeToBranchNodeRelationships,file=f)
			print(verticesDisplacement,file=f)
			print(np.shape(verticesDisplacement),file=f)
			print(NodeToCellFaceCenterRelationships,file=f)
			print(verticesForce,file=f)
			print(np.shape(verticesForce),file=f)
		
		if FOAMySees.config.ApplyGravity=="Yes":
			FOAMySees.prelimAnalysis.runGravity(FOAMySees)
			Displacement=FOAMySees.projectDisplacements(Displacement)
			
		# if FOAMySees.config.runPreliminaryAnalysis=="Yes":
			# FOAMySees.prelimAnalysis.runPreliminaryAnalysis(FOAMySees)
			# Displacement=FOAMySees.projectDisplacements(Displacement)
			
		print("Structure: init precice...")

		meshID = interface.get_mesh_id("Coupling-Data-Projection-Mesh")

		vertexIDsDisplacement = interface.set_mesh_vertices(meshID, verticesDisplacement)

		displacementID = interface.get_data_id("Displacement", meshID)

		vertexIDsForce = vertexIDsDisplacement
		
		forceID = interface.get_data_id("Force", meshID)

		precice_dt = interface.initialize()
	
		with open('FOAMySeesCouplingDriver.log', 'a') as f:
			print('OpenSeesPy (FOAMySees Projected) Initial Displacements (from preliminary analysis)',Displacement)
		

		if interface.is_action_required(action_write_initial_data()):
			print('Initial Displacement',Displacement)
			interface.write_block_vector_data(displacementID, vertexIDsDisplacement, Displacement)
			interface.mark_action_fulfilled(action_write_initial_data())

		interface.initialize_data()
		Popen('rm -rf SeesCheckpoints', shell=True, stdout=DEVNULL).wait()
		Popen('mkdir SeesCheckpoints', shell=True, stdout=DEVNULL).wait()
		Popen('mkdir SeesCheckpoints/checkpoints/', shell=True, stdout=DEVNULL).wait()
		if interface.is_read_data_available():
			force = interface.read_block_vector_data(forceID, vertexIDsForce)

		if interface.is_action_required(action_write_iteration_checkpoint()):
			ops.database('File',"SeesCheckpoints/checkpoint")
			ops.save(0)
			interface.mark_action_fulfilled(action_write_iteration_checkpoint())
			thisTime=copy.deepcopy(ops.getTime())
			with open('What is Happening With OpenSees.log', 'a+') as f:
				print('Wrote a checkpoint at opensees time = ',thisTime,file=f)		
			
		
		FOAMySees.createRecorders.createPVDRecorder(FOAMySees)
		

		FOAMySees.createRecorders.createNodeRecorders(FOAMySees,FOAMySees.nodeRecInfoList)				

		#if interface.is_action_required(action_read_initial_data()):
		#	print('Initial Force',Force)
		#	interface.read_block_vector_data(forceID, vertexIDsForce, Force)
		#	interface.mark_action_fulfilled(action_read_initial_data())
		
		Popen('rm -rf SeesCheckpoints', shell=True, stdout=DEVNULL).wait()
		
		Popen('mkdir SeesCheckpoints', shell=True, stdout=DEVNULL).wait()
		Popen('mkdir SeesCheckpoints/checkpoints/', shell=True, stdout=DEVNULL).wait()
	

				
		stepOut=1
		FOAMySees.lastForces=copy.deepcopy(FOAMySees.force)
		FOAMySees.lastMoments=copy.deepcopy(FOAMySees.moment)

		observe_node_num=1

		tOUT=0
		tLIST=[]
		
		FOAMySees.timeInt()
		
		FOAMySees.CurrSteps=1
	
		StepCheck=1
		
		newStep=1
		

		if  rank ==0:
			while interface.is_coupling_ongoing():
			
				if (interface.is_action_required(precice.action_write_iteration_checkpoint())) or newStep==1:
						
					FOAMySees.writeCheckpoint(stepOut)
					interface.mark_action_fulfilled(precice.action_write_iteration_checkpoint())

				Forces=interface.read_block_vector_data(forceID, vertexIDsForce)
				
				for node in FOAMySees.NodeToCellFaceCenterRelationships:
					FOAMySees.force[node[0],:]=np.sum(Forces[node[1:],:],axis=0)
					
				FOAMySees.calculateUpdatedMoments(Forces)
				
				FOAMySees.createRecorders.createNodeRecorders(FOAMySees,FOAMySees.nodeRecInfoList)	
				
				StepCheck=FOAMySees.stepForward(FOAMySees.dt)	   
				
				with open('What is Happening With OpenSees.log', 'a+') as f:
					print(ops.getTime(),' = OpenSees time\n', FOAMySees.CurrSteps, ' = Number of OpenSees Steps',file=f)

				if (StepCheck!=0):
					with open('What is Happening With OpenSees.log', 'a+') as f:
						print(' OpenSeesPy Step did not converge :(',FOAMySees.thisTime,file=f)
					
				Displacement=FOAMySees.projectDisplacements(Displacement)

				interface.write_block_vector_data(displacementID, vertexIDsDisplacement, Displacement)
				
				precice_dt=interface.advance(precice_dt)
				
				if interface.is_action_required(precice.action_read_iteration_checkpoint()):
					#FOAMySees.CurrSteps+=1				
					FOAMySees.readCheckpoint(stepOut)
					StepCheck=0
					interface.mark_action_fulfilled(precice.action_read_iteration_checkpoint())		 			
				else:
					newStep=1
					tOUT+= precice_dt
					FOAMySees.CurrSteps=1
					stepOut+=1
					FOAMySees.StepsPerFluidStep=1
					FOAMySees.lastForces=copy.deepcopy(FOAMySees.force)
					#ops.wipe()
					ops.record()
					FOAMySees.createRecorders.appendRecords(FOAMySees,FOAMySees.nodeRecInfoList)		
					Popen("ls -t SeesCheckpoints/checkpoints/*| tail -n +100 | xargs -d '\n' rm", shell=True, stdin=None, stdout=None, stderr=None,)
					
					if tOUT>=FOAMySees.config.SeesVTKOUTRate:
						tOUT=0

						FOAMySees.createRecorders.createPVDRecorder(FOAMySees)
		

		print("Exiting FOAMySees Coupling Driver")

		interface.finalize()
