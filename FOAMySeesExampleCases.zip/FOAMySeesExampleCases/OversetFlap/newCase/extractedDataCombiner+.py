import numpy as np, os, re, subprocess

# Execute the log file reading bash script
#subprocess.call("./logFileDataExtracter.sh") # NOTE: if a "permission denied" error pops up, execute "chmod +x extractOrientationAndTime.sh" before using this script again

# Determine the mesh directories from which data will be loaded and processed
# dirContents = os.listdir('.')
#meshDirs = []
#for obj in dirContents:
#	if re.match('mesh',obj):
#		meshDirs.append(obj)
#sortedMeshDirs = sorted(meshDirs, key=lambda x: int(x.split("h")[1]))
path = "/mmfs1/gscratch/cesg/riddl075/OpenFOAM/OversetGridSimulations/PSModel3/background"
#path = "/mmfs1/gscratch/cesg/riddl075/OpenFOAM/OversetGridSimulations/BMModel_Period+Spr/background"
dirs = os.listdir(path)

if os.path.isdir('/gscratch/sw/contrib/OpenFOAM7-CESG/OpenFOAM-7/tutorials/multiphase/interDyMFoam'):
	solver = 'interDyMFoam'
else:
	solver = 'overInterDyMFoam'
# finalMeshContents = os.listdir(sortedMeshDirs[-1])
#Nlogs = 0
#for obj in finalMeshContents:
#	if re.match('log.'+solver,obj):
#		Nlogs = Nlogs+1
#if Nlogs == 0:
#	Nmeshes = len(sortedMeshDirs)-1
#else:
#	Nmeshes = len(sortedMeshDirs)

# Initialize data lists
theta = []
time = []
com = []
angVel = []
thetaOffset = 0.0
moment = []

# Load and process all data, looping through each mesh directory
#for dir in sortedMeshDirs[0:Nmeshes]:
#dirContents = os.listdir(dir+'/extractedData')
dirContents = os.listdir(path+'/extractedData+')
	
# Load paddle orientation tensor and determine rotation angle
OHist = []
for obj in dirContents:
	if re.match('orientHist',obj):
		OHist.append(obj)
#sortedOHist = sorted(OHist, key=lambda x: int(filter(str.isdigit, x)))
for hist in OHist:
	fileName = path+'/extractedData+'+'/'+hist
	fO = open(fileName,'r')
	Oline = fO.readline()
	OsplitLine = Oline.split()
	while Oline:
		nx = float(OsplitLine[1][1:])
		ny = -float(OsplitLine[3])
		refAng = np.arctan(ny/nx)*180/np.pi
		if nx < 0 and ny < 0:
			theta.append(str(refAng-180))
		elif nx == 0 and ny == -1:
			theta.append(str(-90))
		elif nx > 0 and ny < 0:
			theta.append(str(refAng))
		elif nx == 1 and ny == 0:
			theta.append(0)
		elif nx > 0 and ny > 0:
			theta.append(str(refAng))
		elif nx == 0 and ny == 1:
			theta.append(str(90))
		elif nx < 0 and ny > 0:
			theta.append(str(refAng+180))
		else:
			if theta[-1] < 0:
				theta.append('-180')
			else:
				theta.append('180')
		Oline = fO.readline()
		OsplitLine = Oline.split()
	fO.close()
#thetaOffset = float(theta[-1])

# Load time list
#fileName = dir+'/extractedData'+'/timeHist.txt'
fileName = path+'/extractedData+'+'/timeHist.txt'
fT = open(fileName,'r')
Tline = fT.readline()
TsplitLine = Tline.split()
while Tline:
	time.append(TsplitLine[2])
	Tline = fT.readline()
	TsplitLine = Tline.split()
fT.close()

# Load center-of-mass list
fileName = path+'/extractedData+'+'/comHist.txt'
fCOM = open(fileName,'r')
comLine = fCOM.readline()
comSplitLine = comLine.split()
while comLine:
	com.append(comSplitLine[3][1:]+' '+comSplitLine[5][0:len(comSplitLine[5])-1]) # leave out the y-axis component since it is fixed as 0
	comLine = fCOM.readline()
	comSplitLine = comLine.split()
fCOM.close()

# Load angular velocity list
fileName = path+'/extractedData+'+'/angVelHist.txt'
fAV = open(fileName,'r')
avLine = fAV.readline()
avSplitLine = avLine.split()
while avLine:
	angVel.append(avSplitLine[3]) # only save the y-axis component since this is the flap rotation axis
	avLine = fAV.readline()
	avSplitLine = avLine.split()
fAV.close()

# Load moment list
fileName = path+'/extractedData+'+'/momHist.txt'
fM = open(fileName,'r')
mLine = fM.readline()
mSplitLine = mLine.split()
while mLine:
	moment.append(mSplitLine[6])
	mLine = fM.readline()
	mSplitLine = mLine.split()
fM.close()


# Write extracted data histories to file
fileName = 'extractedDataHistories+.txt'
if os.path.exists(fileName):
	os.remove(fileName)
with open(fileName,'w') as fout:
	fout.write("Time Theta Xcom Zcom Omega Moment\n")
	fout.write("s    rad   m    m    rad/s N-m\n")
	for i in range(0,len(theta)-1):
		fout.write("%s %s %s %s %s\n" % (time[i],theta[i],com[i],angVel[i],moment[i]))

