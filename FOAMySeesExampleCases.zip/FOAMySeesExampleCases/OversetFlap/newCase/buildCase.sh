#!/bin/sh
#SBATCH --job-name=PS3Overset
#SBATCH --account=cesg
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=40 # each cesg group node has 40 total "cores" (i.e. 2 threads per 20 slots), but the UW Hyak Wiki recommends using 28 to run jobs most efficiently
#SBATCH --mem=120G
#SBATCH --time=72:00:00
#SBATCH --mail-type=ALL
#SBATCH --mail-user=riddl075@uw.edu

echo determining parallel processing parameters...
NPROC=$SLURM_NTASKS

echo "loading OpenFOAM-v2012..."
source /sw/contrib/cesg-src/spack/share/spack/setup-env.sh
spack load openmpi@4.0.5
source /mmfs1/sw/contrib/cesg-src/spack/opt/spack/linux-centos8-cascadelake/gcc-10.2.0/openfoam-2012-zwozxdqe6kqlwylhxfgffude73illucn/etc/bashrc # set the OpenFOAM environment variables, command aliases, etc...

cd background
#echo decomposePar settting up parallel case...
#NprocLine=$(grep "numberOfSubdomains " ./system/decompParDict_run)
#sed -i "s/$NprocLine/numberOfSubdomains   $NPROC;/g" ./system/decompParDict_run
#cp ./system/decompParDict_run ./system/decomposeParDict
#decomposePar -fileHandler collated > log.decomp_run

echo start mpirun overInterDyMFoam...
mpirun -np $NPROC overInterDyMFoam -fileHandler collated -parallel > log.overInterDyMFoam11

#mpirun -np $NPROC overInterDyMFoam -postProcess -func interfaceHeight -fileHandler collated -parallel > log.overInterDyMFoam3


