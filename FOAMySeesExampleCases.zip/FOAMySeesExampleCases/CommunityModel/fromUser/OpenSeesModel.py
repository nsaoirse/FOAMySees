ops.wipe()

FOAMySeesInstance.coupledNodes=[]

FOAMySeesInstance.osi=ops.model('basic','-ndm',3,'-ndf',6)

RunEQ=0

storyHeight=4
storyDriftLimit=0.025
STORYWEIGHT=1e4
BLDG1XDir=[1,0,0]
BLDG2XDir=[1,0,0]
BLDG3XDir=[1,0,0]
BLDG4XDir=[1,0,0]
BLDG5XDir=[1,0,0]

XSTORYSTIFF=1e9
YSTORYSTIFF=1e9
ZSTORYSTIFF=1e12
XXSTORYSTIFF=1e12
YYSTORYSTIFF=1e12
ZZSTORYSTIFF=1e7

XBLDG1,YBLDG1,HBDG1=[40,20,10]
NSTORYBLDG1=2
BLDG1STORYSTIFFNESSES=[[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF]]
BLDG1STORYWEIGHT=STORYWEIGHT
BLDG1STORYRotMassInertiasXYZ=[1e6,1e6,1e4]
BLDG1STORYWEIGHTS=[[BLDG1STORYWEIGHT,BLDG1STORYRotMassInertiasXYZ[:]],[BLDG1STORYWEIGHT,BLDG1STORYRotMassInertiasXYZ[:]]]

XBLDG2,YBLDG2,HBDG2=[20,10,20]
NSTORYBLDG2=4
BLDG2STORYSTIFFNESSES=[[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF]]
BLDG2STORYWEIGHT=STORYWEIGHT
BLDG2STORYRotMassInertiasXYZ=[1e6,1e6,1e4]
BLDG2STORYWEIGHTS=[[BLDG2STORYWEIGHT,BLDG2STORYRotMassInertiasXYZ[:]],[BLDG2STORYWEIGHT,BLDG2STORYRotMassInertiasXYZ[:]],[BLDG2STORYWEIGHT,BLDG2STORYRotMassInertiasXYZ[:]],[BLDG2STORYWEIGHT,BLDG2STORYRotMassInertiasXYZ[:]]]

XBLDG3,YBLDG3,HBDG3=[60,00,36]
NSTORYBLDG3=8
BLDG3STORYSTIFFNESSES=[[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF]]
BLDG3STORYWEIGHT=STORYWEIGHT
BLDG3STORYRotMassInertiasXYZ=[1e6,1e6,1e4]
BLDG3STORYWEIGHTS=[[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]],[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]],[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]],[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]],[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]],[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]],[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]],[BLDG3STORYWEIGHT,BLDG3STORYRotMassInertiasXYZ[:]]]

XBLDG4,YBLDG4,HBDG4=[40,-10,24]
NSTORYBLDG4=5
BLDG4STORYSTIFFNESSES=[[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF]]
BLDG4STORYWEIGHT=STORYWEIGHT
BLDG4STORYRotMassInertiasXYZ=[1e6,1e6,1e4]
BLDG4STORYWEIGHTS=[[BLDG4STORYWEIGHT,BLDG4STORYRotMassInertiasXYZ[:]],[BLDG4STORYWEIGHT,BLDG4STORYRotMassInertiasXYZ[:]],[BLDG4STORYWEIGHT,BLDG4STORYRotMassInertiasXYZ[:]],[BLDG4STORYWEIGHT,BLDG4STORYRotMassInertiasXYZ[:]],[BLDG4STORYWEIGHT,BLDG4STORYRotMassInertiasXYZ[:]]]

XBLDG5,YBLDG5,HBDG5=[20,-20,16]
NSTORYBLDG5=3
BLDG5STORYSTIFFNESSES=[[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF],[XSTORYSTIFF,YSTORYSTIFF,ZSTORYSTIFF,XXSTORYSTIFF,YYSTORYSTIFF,ZZSTORYSTIFF]]
BLDG5STORYWEIGHT=STORYWEIGHT
BLDG5STORYRotMassInertiasXYZ=[1e6,1e6,1e4]
BLDG5STORYWEIGHTS=[[BLDG5STORYWEIGHT,BLDG5STORYRotMassInertiasXYZ[:]],[BLDG5STORYWEIGHT,BLDG5STORYRotMassInertiasXYZ[:]],[BLDG5STORYWEIGHT,BLDG5STORYRotMassInertiasXYZ[:]]]


bldgLocs=[[XBLDG1,YBLDG1,HBDG1,NSTORYBLDG1,BLDG1STORYSTIFFNESSES,BLDG1STORYWEIGHTS,BLDG1XDir],[XBLDG2,YBLDG2,HBDG2,NSTORYBLDG2,BLDG2STORYSTIFFNESSES,BLDG2STORYWEIGHTS,BLDG2XDir],[XBLDG3,YBLDG3,HBDG3,NSTORYBLDG3,BLDG3STORYSTIFFNESSES,BLDG3STORYWEIGHTS,BLDG3XDir],[XBLDG4,YBLDG4,HBDG4,NSTORYBLDG4,BLDG4STORYSTIFFNESSES,BLDG4STORYWEIGHTS,BLDG4XDir],[XBLDG5,YBLDG5,HBDG5,NSTORYBLDG5,BLDG5STORYSTIFFNESSES,BLDG5STORYWEIGHTS,BLDG5XDir]]

nodeRecInfoList=[]

FOAMySeesInstance.nameOfAllFSIStoryDisplacementTimeHistories=[]

FOAMySeesInstance.nameOfAllFSIStoryForceTimeHistories=[]

FOAMySeesInstance.nameOfAllPreliminaryStoryDisplacementTimeHistories=[]

FOAMySeesInstance.nameOfAllPreliminaryStoryForceTimeHistories=[]

pc=1
for location in bldgLocs:

	node1=[location[0], location[1],  0.0]
	node2=[location[0], location[1], location[2]]

	beamNormal=[-1,0,0]


	xNodeList=np.linspace(node1[0],node2[0],location[3]+1)
	yNodeList=np.linspace(node1[1],node2[1],location[3]+1)
	zNodeList=np.linspace(node1[2],node2[2],location[3]+1)

	bottomNode=0
	for nodeNum in range(pc*1000, pc*1000+len(xNodeList)):
		ops.node(nodeNum, xNodeList[nodeNum-pc*1000],yNodeList[nodeNum-pc*1000],zNodeList[nodeNum-pc*1000])

		if bottomNode==1:
			FOAMySeesInstance.coupledNodes.append(nodeNum)
		if bottomNode==0:
			bottomNode=1
			nodeRecInfoList.append(['FSI_BaseReaction_BLDG'+str(pc)+'.out',nodeNum,'reaction'])
			FOAMySeesInstance.nameOfAllFSIStoryForceTimeHistories.append('FSI_BaseReaction_BLDG'+str(pc)+'.out')
			ops.recorder('Node', '-file', 'Preliminary_'+'BaseReaction_BLDG'+str(pc)+'.out','-time', '-node', nodeNum, '-dof', 1,2,3,4,5,6, 'reaction')
			FOAMySeesInstance.nameOfAllPreliminaryStoryForceTimeHistories.append('Preliminary_BaseReaction_BLDG'+str(pc)+'.out')
			
	#############################
	
	dirs=[1,2,3,4,5,6]
	storyCt=0
	directionKey=['BuildingX','BuildingY','Z','XXOverturn','YYOverturn','Story Torsion']
	for nodeNum in range(pc*1000+1, pc*1000+len(xNodeList)):
		matTags=[]
		storyStiffness=location[4][storyCt]
		for direction in range(0,5):
			storyHeight=3
			storyDriftLimit=0.1 #percent Drift
			matTag=pc*1000+(100*(storyCt+1))+ direction
			E=storyStiffness[direction]
			print('Building: ',pc,' Story: ',storyCt+1,', Direction: ',directionKey[direction],', Direction Stiffness: ',E)
			epsP=storyDriftLimit/storyHeight
			#ops.uniaxialMaterial('ElasticPP', matTag, E, epsyP)
			#ops.uniaxialMaterial('ElasticBilin', matTag, E, E/2, epsP)
			ops.uniaxialMaterial('Elastic', matTag, E)
			matTags.append(pc*1000+(100*(storyCt+1))+ direction)
		
		
		
		ops.element('twoNodeLink', nodeNum, *[nodeNum-1, nodeNum], '-mat', *matTags, '-dir', *dirs, '-orient', *location[6], *[np.cross([0,0,1],location[6])])
		storyCt+=1
		nodeRecInfoList.append(['FSI_Displacement_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out',nodeNum,'disp'])
		FOAMySeesInstance.nameOfAllFSIStoryDisplacementTimeHistories.append('FSI_Displacement_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out')
		
		nodeRecInfoList.append(['FSI_StoryForce_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out',nodeNum,'reaction'])
		FOAMySeesInstance.nameOfAllFSIStoryForceTimeHistories.append('FSI_StoryForce_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out')
		
		ops.recorder('Node', '-file', 'Preliminary_'+'Displacement_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out','-time', '-node', nodeNum, '-dof', 1,2,3,4,5,6, 'disp')
		
		FOAMySeesInstance.nameOfAllPreliminaryStoryDisplacementTimeHistories.append('Preliminary_'+'Displacement_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out')
		
		ops.recorder('Node', '-file', 'Preliminary_'+'StoryForce_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out','-time', '-node', nodeNum, '-dof', 1,2,3,4,5,6, 'reaction')
		
		FOAMySeesInstance.nameOfAllPreliminaryStoryForceTimeHistories.append('Preliminary_'+'StoryForce_BLDG'+str(pc)+'_Story'+str(storyCt)+'.out')
		
	nodRotMass=0.
	storyCt=0
	for nodeNum in range(pc*1000+1, pc*1000+len(xNodeList)):
		print('Building: ',pc,' Story: ',storyCt+1,'Story Masses: ',location[5][storyCt])
		ops.mass(nodeNum,*[location[5][storyCt][0],location[5][storyCt][0],location[5][storyCt][0],location[5][storyCt][1][0],location[5][storyCt][1][1],location[5][storyCt][1][2]])
		storyCt+=1

	pc+=1
	
ops.fixZ(0.00,*[1,1,1,1,1,1])

damping=0.0500
z1=damping
z2=damping
f1=8.40
f2=f1*5 


alphaM = 0.000 # (4*3.1415*f1*f2)*((z1*f2 - z2*f1)/(f2**2 - f1**2))               # M-prop. damping; D = alphaM*M    

betaKcurr = 00.00 # K-proportional damping;      +beatKcurr*KCurrent <- not this

betaKinit = ((z1*f2 - z2*f1)/(3.1415*(f2**2 - f1**2))) # initial-stiffness proportional damping      +beatKinit*Kini <<<<<<<<<------------------------------ use this 
betaKcomm = 0.0
ops.rayleigh(alphaM,betaKcurr, betaKinit, betaKcomm) # RAYLEIGH damping
try:
    ################# CHECKING FOR IMPLICIT ANALYSIS COMPATIBILITY
    ops.database('File',"checkpoint")
    ops.save(0)
    print('Wrote a checkpoint, if this fails, the model has elements, materials, or sections which are not supported in Implicitly coupled FSI analyses')
    ops.restore(0)
    print('Read a checkpoint, all elements and materials are OK for Implicitly coupled analysis')
    ################# CHECKING FOR IMPLICIT ANALYSIS COMPATIBILITY
except:
    print('There are elements or materials in the domain which cannot be saved to a database, coupling scheme should be switched to an explicit routine')

res=['disp','vel','accel','incrDisp','reaction','pressure','unbalancedLoad','mass']

os.system('rm -rf SeesoutPrelim')
os.system('mkdir SeesoutPrelim')
os.system('touch SeesoutPrelim.pvd')
ops.recorder('PVD', 'SeesoutPrelim', '-precision', 4, '-dT', 0.1, *res)

if RunEQ==1:


	GMfile='./fromUser/GroundMotion.acc'
	# Uniform EXCITATION: acceleration input
	IDloadTag = 400			# load tag
	dt = 0.1			# time step for input ground motion
	GMfact = 0.0001		   # data in input file is in g Unifts -- ACCELERATION TH
	maxNumIter = 100
	GMdirection=1
	Tol=1e-6

	TSTAG=2

	ops.timeSeries('Path', TSTAG, '-dt', dt, '-filePath', GMfile, '-factor', GMfact, '-useLast')

	ops.pattern('UniformExcitation', IDloadTag, GMdirection, '-accel', TSTAG) 


	ops.constraints('Transformation')
	ops.numberer('Plain')
	ops.system('BandGeneral')
	ops.test('NormUnbalance', Tol, maxNumIter)
	ops.algorithm('ModifiedNewton')
	NewmarkGamma = 0.5
	NewmarkBeta = 0.25
	ops.integrator('Newmark', NewmarkGamma, NewmarkBeta)
	ops.analysis('VariableTransient')
	DtAnalysis = 0.001
	TmaxAnalysis = 100
	Nsteps =  int(TmaxAnalysis/ DtAnalysis)
	ok=1
	# for i in test:
	ops.algorithm('KrylovNewton')

	ok = ops.analyze(Nsteps, DtAnalysis,DtAnalysis/10,DtAnalysis,100)	
	ops.remove('loadPattern',IDloadTag)
	ops.remove('timeSeries', TSTAG) 

FOAMySeesInstance.nodeRecInfoList=nodeRecInfoList
for x in FOAMySeesInstance.nameOfAllFSIStoryDisplacementTimeHistories:
	with open('AllTimeHistories', 'a+') as f:
		print(x,file=f)	
for x in FOAMySeesInstance.nameOfAllFSIStoryForceTimeHistories:
	with open('AllTimeHistories', 'a+') as f:
		print(x,file=f)		
for x in FOAMySeesInstance.nameOfAllPreliminaryStoryDisplacementTimeHistories:
	with open('AllTimeHistories', 'a+') as f:
		print(x,file=f)	
for x in FOAMySeesInstance.nameOfAllPreliminaryStoryForceTimeHistories:
	with open('AllTimeHistories', 'a+') as f:
		print(x,file=f)	
			