import os 
import sys
import json
import numpy as np
from subprocess import Popen, DEVNULL
sys.path.append('./OpenSeesSettings')

from geometrySettings import *
from materialSettings import *
from fixitySettings import *
from timeSettings import *
from OpenSeesPySettings import *
from mappingSettings import *
from dampingSettings import *
from outputSettings import *

fluidExists=0

with open("NPROCRUN", "r") as f:
	for line in f:
		try:
			NPROCRUN=int(line)
		except: 
			pass
			
outputRateUQForcesAndPressures=1
DomainDecomposition=NPROCRUN

f = open('fromUser/scInput.json')
prelimAnalysisExists=0
VELTH=0
PADDLETH=0	
AllJSONVars=[]
# returns JSON object as 
# a dictionary
data = json.load(f)
for keys , values in data.items():
	#print(keys, values) 
	if (keys=='GeneralInformation'):	
		for xx in values:
			#print(xx,data[keys][xx])
			if xx=='NumberOfStories':
				numStories=data[keys][xx]


	if (keys=='Events'):
		for x in values[0]:
			#print(x,values[0][x])
			AllJSONVars.append([x,values[0][x]])

# Closing file
f.close()
#print('All JSON Variables ',AllJSONVars)
bathExists=0
for idx, x in enumerate(AllJSONVars[:]): 
	if x[0]=='Turbulence':									#
		Turbulence=x[1]
		AllJSONVars.remove(x)
		
	if x[0]=='FOAMVTKOUT':									#
		FOAMVTKOUT=x[1]
		AllJSONVars.remove(x)
	
	if x[0]=='FOAMVTKOUTRate':								#
		FOAMVTKOUTRate=float(x[1])
		AllJSONVars.remove(x)
						
	if x[0]=='SeesVTKOUT':									#
		SeesVTKOUT=x[1]
		AllJSONVars.remove(x)
	
	if x[0]=='SeesVTKOUTRate':								#
		SeesVTKOUTRate=float(x[1])
		AllJSONVars.remove(x)
		
	if x[0]=='writeDT':									   #
		writeDT=float(x[1])
		AllJSONVars.remove(x)

	if x[0]=='SimDuration':								   #
		endTime=float(x[1])
		AllJSONVars.remove(x)

	if x[0]=='SolutionDT':									#
		SolutionDT=float(x[1])		
		AllJSONVars.remove(x)  

	if x[0]=='AdjustTimeStep':								#
		AdjustTimeStep="false"   
		if x[1]=="Yes":
			AdjustTimeStep="true"
		AllJSONVars.remove(x)
	
	if x[0]=='ApplyGravity':								  #
		ApplyGravity=x[1]	   
		AllJSONVars.remove(x)   
		
	# if x[0]=='PreliminaryAnalysis':								  #
		# runPreliminaryAnalysis=x[1]	   
		# AllJSONVars.remove(x)   
	# if x[0]=='preliminaryAnalysisFilePath': 
		# preliminaryAnalysisFilePath=x[1].strip('.')
		# AllJSONVars.remove(x)
	
	# if x[0]=='preliminaryAnalysisFile':
		# preliminaryAnalysisFile='preliminaryAnalysis.py'
		# AllJSONVars.remove(x)
		# prelimAnalysisExists=1
		
	if x[0]=='CouplingScheme':								#
		CouplingScheme=x[1]	   
		if CouplingScheme=='Implicit':
			implicit=1
		else:
			implicit=0
		AllJSONVars.remove(x)
		
	if x[0]=='bathType':									  #
		bathType=x[1]	   
		bathExists=1
		AllJSONVars.remove(x)  

	if x[0]=='bathXZData':									#
		bathXZData=x[1]	   
		AllJSONVars.remove(x)
		
	if x[0]=='bathSTL':									#
		bathSurfaceFile=x[1]	   
		AllJSONVars.remove(x)
		
	if x[0]=='bathSTLPath':									#
		bathSTLPath=x[1]	   
		AllJSONVars.remove(x)
		
	if x[0]=='couplingConvergenceTol':						#
		couplingConvergenceTol=float(x[1])	   
		AllJSONVars.remove(x)	   
		
	if x[0]=='couplingDataAccelerationMethod':				#
		couplingDataAccelerationMethod=x[1]
		AllJSONVars.remove(x)
			
	if x[0]=='couplingIterationOutputDataFrequency':		  #
		couplingIterationOutputDataFrequency=x[1]
		AllJSONVars.remove(x)
			   
	if x[0]=='cutSurfaceLocsDirsFields':					  #
		cutSurfaceLocsDirsFields=x[1]
		AllJSONVars.remove(x)			   
		
	if x[0]=='cutSurfaceOutput':							  #
		cutSurfaceOutput=x[1]
		AllJSONVars.remove(x)
	
	if x[0]=='domainSubType':								 #
		domainSubType=x[1]
		AllJSONVars.remove(x)  
		
	if x[0]=='fieldProbeLocs':								#
		fieldProbeLocs=x[1]
		AllJSONVars.remove(x)
		
	if x[0]=='fieldProbes':								   #
		fieldProbes=x[1]
		AllJSONVars.remove(x)		   
		
	if x[0]=='freeSurfProbeLocs':								#
		freeSurfProbeLocs=x[1]
		AllJSONVars.remove(x)
		
	if x[0]=='freeSurfOut':								   #
		freeSurfOut=x[1]
		AllJSONVars.remove(x)		
				
	if x[0]=='freeSurfProbes':								   #
		freeSurfProbes=x[1]
		AllJSONVars.remove(x)		
		
	if x[0]=='flumeHeight':								   #
		flumeHeight=float(x[1])
		AllJSONVars.remove(x)	 
		
	if x[0]=='flumeLength':								   #
		flumeLength=float(x[1])
		AllJSONVars.remove(x)		
		
	if x[0]=='flumeWidth':								   #
		flumeWidth=float(x[1])
		AllJSONVars.remove(x)	
		
	if x[0]=='cellSize':								   #
		cellSize=float(x[1])
		AllJSONVars.remove(x)	
		
	if x[0]=='g':								   #
		g=[0,0,float(x[1])]
		AllJSONVars.remove(x)
				
	if x[0]=='initVelocity':								   #
		initVelocity=float(x[1])
		AllJSONVars.remove(x)				
		
	if x[0]=='initialRelaxationFactor':								   #
		initialRelaxationFactor=float(x[1])
		AllJSONVars.remove(x)   
	
	if x[0]=="interfaceSurfacePath":
		interfaceSurfacePath=x[1]	
		AllJSONVars.remove(x)  
		
	if x[0]=="interfaceSurface":
		interfaceSurface=x[1]
		AllJSONVars.remove(x)  
		
	if x[0]=='interfaceSurfaceOutput':								   #
		interfaceSurfaceOutput=x[1]
		AllJSONVars.remove(x) 
		
	if x[0]=='mapType':								   #
		if x[1] == "Nearest Neighbor":
			mapType='nearest-neighbor'
		elif x[1] == "RBF Thin Plate Splines":
			mapType='rbf-thin-plate-splines'
		AllJSONVars.remove(x)	  

	if x[0]=='maximumCouplingIterations':								   #
		maximumCouplingIterations=x[1]
		AllJSONVars.remove(x)			
		
	if x[0]=='outputDataFromCouplingIterations':								   #
		outputDataFromCouplingIterations=x[1]
		AllJSONVars.remove(x)
		
	if x[0]=='runPrelim':								   #
		if x[1]=="Yes":
			runPrelim=1
		else:
			runPrelim=0
		AllJSONVars.remove(x)
		
	if x[0]=='periodicWaveCelerity':								   #
		periodicWaveCelerity=float(x[1])
		AllJSONVars.remove(x)		
				
	if x[0]=='periodicWaveMagnitude':								   #
		periodicWaveMagnitude=float(x[1])
		AllJSONVars.remove(x)		
				
	if x[0]=='periodicWaveRepeatPeriod':								   #
		periodicWaveRepeatPeriod=float(x[1])
		AllJSONVars.remove(x)
		
	if x[0]=='refPressure':								   #
		refPressure=float(x[1])
		AllJSONVars.remove(x)						

	if x[0]=='stillWaterLevel':								   #
		stillWaterLevel=float(x[1])
		AllJSONVars.remove(x)		

	if x[0]=='turbIntensity':								   #
		turbIntensity=float(x[1])
		AllJSONVars.remove(x)		

	if x[0]=='turbRefLength':								   #
		turbRefLength=float(x[1])
		AllJSONVars.remove(x)		

	if x[0]=='turbReferenceVel':								   #
		turbReferenceVel=float(x[1])
		AllJSONVars.remove(x)		
		
	if x[0]=='openSeesPyScript':
		openSeesPyScript=x[1]
		AllJSONVars.remove(x)	
		
	if x[0]=='openSeesPyScriptPath':
		openSeesPyScriptPath=x[1]
		AllJSONVars.remove(x)

		
	if x[0]=='waveType':								   #
		waveType=x[1]
		if waveType=='Paddle Generated Waves':
			PADDLETH=1
		AllJSONVars.remove(x)
		
	if x[0]=='velocityFile': 
		if x[1]!="":
			velocityFile=x[1]
			VELTH=1
		AllJSONVars.remove(x)  
			
	if x[0]=='velocityFilePath': 
		if x[1]!="":
			velocityFilePath=x[1]
			import csv
			with open(x[1].strip('.')+velocityFile,'r') as dest_f:
				data_iter = csv.reader(dest_f,
									   delimiter = ',',
									   quotechar = '"')
				data = [data for data in data_iter]
			velTimeData = np.asarray(data, dtype = np.float32)
		AllJSONVars.remove(x)  	
				
	if x[0]=="paddleDispFilePath": 
		if x[1]!="":
			paddleDispFilePath=x[1]
		AllJSONVars.remove(x)  
		
	if x[0]=='paddleDispFile':  
		if x[1]!="":
			paddleDispFile=x[1]
		AllJSONVars.remove(x)  
			

	###################################################################
	
	if x[0]=='fileName':										#
		prelimAnalysisFile=x[1]
		AllJSONVars.remove(x)
		
	if x[0]=='filePath':										#
		prelimAnalysisFilePathPrefix=x[1]
		AllJSONVars.remove(x)
		
	######################################################### 
useBranches=1
DiffBranchesAcrossParts=0
KDTreeClusteringToFluidMesh=1
if __name__=="__main__":
	# CONFIGURE OPENSEES 
				
	PRELIM=['''
import os
import concurrent.futures
import logging
import queue
import random
import subprocess
import time

import pandas as pd
import re, csv
import matplotlib
import argparse
import numpy as np
import configuration_file as config
import buildOpenSeesModelInThisFile as userModel

import math as m
import copy

import sys
import math

import meshio

import openseespy.opensees as ops
from openseespy.opensees import *
sys.path.insert(0, '../OpenSeesSettings')
def runGravity(self):
	
	if config.ApplyGravity=='yes':

		res=['disp','vel','accel','incrDisp','reaction','pressure','unbalancedLoad','mass']

		os.system('rm -rf SeesoutGrav')
		os.system('mkdir SeesoutGrav')
		os.system('touch SeesoutGrav.pvd')
		recorder('PVD', 'SeesoutGrav', '-precision', 4, '-dT', 0.1, *res)
		IDloadTag = 400			# load tag
		dt = 0.001			# time step for input ground motion
		
		maxNumIter = 10

		Tol=1e-3
		
		ops.timeSeries('Constant', 1, '-factor',1)

		ops.pattern('Plain', 1, 1)
		
		FX=self.config.g[0]
		FY=self.config.g[1]
		FZ=self.config.g[2]   
		for node_num in range(0,len(self.nodeList)):
			NM=ops.nodeMass(self.nodeList[node_num], 1)	
			if self.config.SeesModelType=="solid":
				ops.load(self.nodeList[node_num], NM*FX, NM*FY, NM*FZ)
			else:
				ops.load(self.nodeList[node_num], NM*FX, NM*FY, NM*FZ, 0.0, 0., 0.0) 
	
	if config.runPrelim=='Yes':
		ops.constraints('Transformation')
		ops.numberer('Plain')
		ops.system('BandGeneral')
		ops.test('EnergyIncr', Tol, maxNumIter)
		ops.algorithm('ModifiedNewton')
		NewmarkGamma = 0.5
		NewmarkBeta = 0.25
		ops.integrator('Newmark', NewmarkGamma, NewmarkBeta)
		ops.analysis('VariableTransient')
		DtAnalysis = 0.01
		TmaxAnalysis = 100
		Nsteps =  int(TmaxAnalysis/ DtAnalysis)

		ops.algorithm('KrylovNewton')

		ok = ops.analyze(Nsteps, DtAnalysis,DtAnalysis/10,DtAnalysis,100)	
		ops.loadConst('-time',0)  
		
		for node_num in range(0,len(self.nodeList)):
			ops.setNodeVel(self.nodeList[node_num], 1, 0.0, '-commit')
			ops.setNodeVel(self.nodeList[node_num], 2, 0.0, '-commit')
			ops.setNodeVel(self.nodeList[node_num], 3, 0.0, '-commit')
			# ops.setNodeAccel(self.nodeList[node_num], 1, 0.0, '-commit')
			# ops.setNodeAccel(self.nodeList[node_num], 2, 0.0, '-commit')
			# ops.setNodeAccel(self.nodeList[node_num], 3, 0.0, '-commit')

	os.system("rm SeesCheckpoints/checkpoint*")
	ops.database('File',"SeesCheckpoints/checkpoint")
	ops.save(0)
	nope=1

	''']
	# if prelimAnalysisExists==1:
		# with open(preliminaryAnalysisFilePath+preliminaryAnalysisFile,'r') as file:
			# lines = [line.rstrip() for line in file]

	with open('OpenSeesSettings/preliminaryAnalysis.py','w') as f:
		f.seek(0)
		for x in PRELIM:
			for line in x:
				f.write(line)
		# f.write('\t')
		# f.write('''if prelimAnalysisExists==1:		
			# def runPreliminaryAnalysis(self):''')
		
		# if prelimAnalysisExists==1:
			# for line2 in lines:
				# f.write('\t')
				# f.write('\t')
				# f.write('\t')
				# f.write(line2)
				# f.write('\n')
			# f.truncate()


	OSMODEL=['''import os
import concurrent.futures
import logging
import queue
import random
import subprocess
import time
import pandas as pd
import re, csv
import matplotlib
import argparse
import numpy as np


import sys
import math

import openseespy.opensees as ops
def defineYourModelWithinThisFunctionUsingOpenSeesPySyntax(FOAMySeesInstance):
	FOAMySeesInstance.osi=ops.model('basic','-ndm',3,'-ndf',6)
''']

	with open(openSeesPyScriptPath.strip('.')+openSeesPyScript,'r') as file:
		lines = [line.rstrip() for line in file]
		
	with open('OpenSeesSettings/buildOpenSeesModelInThisFile.py','w') as f:
		f.seek(0)
		for x in OSMODEL:
			for line in x:
				f.write(line)
				
		for line2 in lines:
			f.write('\t')
			f.write(line2)
			f.write('\n')
				 
		f.write('''
	try:
		FOAMySeesInstance.coupledNodes=coupledNodes
	except:
		pass
	try: 
		FOAMySeesInstance.nodeRecInfoList=nodeRecInfoList
	except:
		FOAMySeesInstance.nodeRecInfoList=[]
''')
		f.write('\n')   
		f.truncate()



	# CONFIGURE PRECICE 



	count=0
	# OpenFOAM Displacement Probes
	FluidWatchPoints=''''''
	if ofDispProbe==1:
		for ofDispProbeLoc in ofDispProbeLocs:
			FluidWatchPoints+='''
			<watch-point mesh="Fluid-Mesh" name="FluidMeshDisplacementTracer{}" coordinate="{};{};{}" />'''.format(count,ofDispProbeLoc[0],ofDispProbeLoc[1],ofDispProbeLoc[2])
			count+=1
			
	# OpenSeesPy Displacement Probes
	count=0
	SolidWatchPoints=''''''
	if osDispProbe==1:
		for osDispProbeLoc in osDispProbeLocs:
			SolidWatchPoints+='''
			<watch-point mesh="Coupling-Data-Projection-Mesh" name="SolidMeshDisplacementTracer{}" coordinate="{};{};{}" />'''.format(count,osDispProbeLoc[0],osDispProbeLoc[1],osDispProbeLoc[2])
			count+=1
		

	if outputDataFromCouplingIterations=="No":
		doWeOutputPreCICEData=''''''
	else:
		doWeOutputPreCICEData='''<export:vtk every-n-time-windows="{}" directory="preCICE-output" />'''.format(couplingIterationOutputDataFrequency)

	exchangeWhatData='''
		  <exchange data="Force" mesh="Coupling-Data-Projection-Mesh" from="Fluid" to="FOAMySeesCouplingDriver" />
		  <exchange data="Displacement" mesh="Coupling-Data-Projection-Mesh" from="FOAMySeesCouplingDriver" to="Fluid" />
				'''

			
	accelWhatData='''
			<data name="Displacement" mesh="Coupling-Data-Projection-Mesh" />
			<data name="Force" mesh="Coupling-Data-Projection-Mesh" />
				'''
				

	relConvMeasures=''' />
	# 	  <relative-convergence-measure limit="{}" data="Displacement" mesh="Coupling-Data-Projection-Mesh" />
	# 	  <relative-convergence-measure limit="{}" data="Force" mesh="Coupling-Data-Projection-Mesh" />'''.format(couplingConvergenceTol,couplingConvergenceTol)
		  

	accelTypes=['''<acceleration:aitken>
	'''+accelWhatData+'''
	  <initial-relaxation value="{}"/>
	</acceleration:aitken>'''.format(initialRelaxationFactor),
	'''<acceleration:constant>
	  <relaxation value="{}"/>
	</acceleration:constant>'''.format(initialRelaxationFactor),
	'''
		  <acceleration:IQN-ILS>
	'''+accelWhatData+'''		
				<filter type="QR2" limit="1e-16" />
				<initial-relaxation value="{}" />
				<max-used-iterations value="10" />
				<time-windows-reused value="5" />
	  </acceleration:IQN-ILS>'''.format(initialRelaxationFactor),
	  '''<acceleration:IQN-IMVJ always-build-jacobian="0">
	   <initial-relaxation value="{}" enforce="0"/>
	   <imvj-restart-mode truncation-threshold="0.0001" chunk-size="8" reused-time-windows-at-restart="8" type="RS-SVD"/>
	'''+accelWhatData+'''
		<filter type="QR2" limit="1e-16" />
		<max-used-iterations value="10" />
		<time-windows-reused value="5" />
	  <filter type="QR2" limit="1e-12" />
	   <preconditioner freeze-after="-1" type="constant"/>
	 </acceleration:IQN-IMVJ>
	  '''.format(initialRelaxationFactor),
	  '''<acceleration:broyden>'''+accelWhatData+'''
		<initial-relaxation value="{}" />
		<max-used-iterations value="10" />
		<time-windows-reused value="5" />
	</acceleration:broyden>'''.format(initialRelaxationFactor)]

	if couplingDataAccelerationMethod=="Constant":
		accelType=accelTypes[1]
	elif couplingDataAccelerationMethod=="Aitken":
		accelType=accelTypes[0]
	elif couplingDataAccelerationMethod=="IQN-ILS":
		accelType=accelTypes[2]
	elif couplingDataAccelerationMethod=="IQN-IMVJ":
		accelType=accelTypes[3]
	elif couplingDataAccelerationMethod=="Broyden":
		accelType=accelTypes[4]
	else:
		pass



			
	preCICEdict=['''<?xml version="1.0" encoding="UTF-8" ?>
	<precice-configuration>
	  <log>
		   </log>


	  <solver-interface dimensions="3">
		<data:vector name="Force" />
		<data:vector name="Displacement" />

		<mesh name="Fluid-Mesh">
		  <use-data name="Displacement" />
			<use-data name="Force" />
		</mesh>

		<mesh name="Coupling-Data-Projection-Mesh">
		  <use-data name="Displacement" />
		  <use-data name="Force" />
		</mesh>


	  
		<participant name="FOAMySeesCouplingDriver">
	''',doWeOutputPreCICEData,'''
		  <use-mesh name="Coupling-Data-Projection-Mesh" provide="yes" />
		  <write-data name="Displacement" mesh="Coupling-Data-Projection-Mesh" />
		  <read-data name="Force" mesh="Coupling-Data-Projection-Mesh" />
		</participant>
		
		 <participant name="Fluid">
				  ''',FluidWatchPoints,'''
	''',doWeOutputPreCICEData,'''

			  <use-mesh name="Fluid-Mesh" provide="yes" />
		  <use-mesh name="Coupling-Data-Projection-Mesh" from="FOAMySeesCouplingDriver" />
		  <write-data name="Force" mesh="Fluid-Mesh" />
		  <read-data name="Displacement" mesh="Fluid-Mesh" />
		   <mapping:{}'''.format(mapType),'''
			direction="write"
			from="Fluid-Mesh"
			to="Coupling-Data-Projection-Mesh"
			constraint="conservative" />
		   <mapping:{}'''.format(mapType),'''
			direction="read"
			from="Coupling-Data-Projection-Mesh"
			to="Fluid-Mesh"
			constraint="consistent" />
		</participant>
		''']
			  # <mapping:{}'''.format(mapType),'''
			# direction="read"
			# from="Coupling-Data-Projection-Mesh"
			# to="Fluid-Mesh"
		 # constraint="consistent" />
		 
		 
				 # <mapping:{}'''.format(mapType),'''
			# direction="read"
			# to="Coupling-Data-Projection-Mesh"
			# from="Fluid-Mesh"
		 # constraint="consistent" />
			 # <mapping:{}'''.format(mapType),'''
			# direction="write"
			# to="Fluid-Mesh"
			# from="Coupling-Data-Projection-Mesh"
			# constraint="conservative" />

	if implicit==1:
		preCICEdict.append(
		'''
		<m2n:sockets from="Fluid" to="FOAMySeesCouplingDriver" exchange-directory="." />
	   <coupling-scheme:parallel-implicit>
		  <time-window-size value="{}"'''.format(SolutionDT)),
		preCICEdict.append(''' />
				<max-time value="{}"/>'''.format(endTime))
		preCICEdict.append('''
				<participants first="Fluid" second="FOAMySeesCouplingDriver"/>'''+exchangeWhatData+'''
		  <max-iterations value="{}"'''.format(maximumCouplingIterations))
		preCICEdict.append(relConvMeasures)
		preCICEdict.append('''	  
			   
		  ''')
		preCICEdict.append(accelType)
		preCICEdict.append('''
		</coupling-scheme:parallel-implicit>
	  </solver-interface>
	</precice-configuration>
	''')
	else:
		preCICEdict.append(''' 
		<m2n:sockets from="Fluid" to="FOAMySeesCouplingDriver" exchange-directory="Fluid" />
		<coupling-scheme:parallel-explicit>
				<time-window-size value="{}"'''.format(SolutionDT))
		preCICEdict.append(''' />
				<max-time value="{}"/>'''.format(endTime))
		preCICEdict.append('''
				<participants first="Fluid" second="FOAMySeesCouplingDriver"/>'''+exchangeWhatData+'''
	   </coupling-scheme:parallel-explicit>
		 </solver-interface>
	</precice-configuration>
		''')

	with open('precice-config.xml','w') as f:
		f.seek(0)
		for x in preCICEdict:
			for line in x:
				f.write(line)
				f.truncate()
				
					
		
	Popen('cp -r '+openSeesPyScriptPath.strip('.')+openSeesPyScript+' OpenSeesSettings/OpenSeesModel.py', shell=True, stdout=DEVNULL).wait()
	Popen('cp -r '+interfaceSurfacePath.strip('.')+interfaceSurface+' Fluid/constant/triSurface/interface.stl', shell=True, stdout=DEVNULL).wait()



	


					
	pLocations=[]

	X=flumeLength
	Y=flumeWidth
	Z=flumeHeight

	xBlockCt=int(X//cellSize)
	yBlockCt=int(Y//cellSize)
	zBlockCt=int(Z//cellSize)
	zBlockCtSWL=int(stillWaterLevel//cellSize)
	allFunctionObjects=''''''

	if freeSurfOut=='Yes':
		allFunctionObjects+='''
		freeSurfaceVTK
	   {   
		   type			surfaces;
		   functionObjectLibs
		   (   
			   "libsampling.so" 
		   );  
		   outputControl   outputTime;
		   outputInterval  1;  
		   surfaceFormat  vtk;
		   fields
		   (   
			   alpha.water
		   );  
		   surfaces
		   (   
			   freeSurface
			   {   
				   type		isoSurfaceCell;
				   isoField	alpha.water;
				   isoValue	0.5;
				   interpolate false;
				   regularise  false;
			   }   
			   
		   );  
		   interpolationScheme cell;
	   }
	   '''
	   
	count=0   
	   # OpenFOAM Cut Surface Output
	if cutSurfaceOutput=='Yes':
		for cutSurface in cutSurfaceLocsDirsFields:
			fieldsCurr=''''''
			for xx in cutSurface[7].split(','):
				fieldsCurr+='''{}
					   '''.format(xx)
			allFunctionObjects+=cutSurface[6]+'''
			{   
			   type			surfaces;
			   functionObjectLibs
			   (   
				   "libsampling.so" 
			   );  
			   outputControl   outputTime;
			   outputInterval  1;  
			   surfaceFormat  vtk;
			   fields
			   (   
				   '''+fieldsCurr+'''
			   );  
			   surfaces
			   (   
				interpolatedSurface
				{
					// Cutingplane using iso surface
					type			cuttingPlane;
					planeType	   pointAndNormal;
					pointAndNormalDict
					{'''+'''
						basePoint	   ({} {} {});
						normalVector	({} {} {});'''.format(cutSurface[0],cutSurface[1],cutSurface[2],cutSurface[3],cutSurface[4],cutSurface[5])+'''
						}
					interpolate	 true;	   
					}	
			   );  
			   interpolationScheme cell;
		   }
		   '''
		count+=1
	   
	count=0
	   # OpenFOAM Cut Surface Output
	if interfaceSurfaceOutput=='Yes':

		allFunctionObjects+='''structureInterface
		{   
		   type			surfaces;
		   functionObjectLibs
		   (   
			   "libsampling.so" 
		   );  
		   outputControl   outputTime;
		   outputInterval  1;  
		   surfaceFormat  vtk;
		   fields
		   (   
			   '''+fieldsCurr+'''
		   );  
		   surfaces
		   (   
			interface
			{
				type			patch;
				patches	   (interface);	
				}	
		   );  
		   interpolationScheme cell;
	   }
	   '''

	# Free Surface Probes
	probeLocs=''''''
	if freeSurfProbes=='Yes':
		for probeloc in freeSurfProbeLocs:

			allFunctionObjects+='''
			{}'''.format(probeloc[3])+'''
			{
				type			interfaceHeight;
				libs			("libfieldFunctionObjects.so");
				writeControl	timeStep; 
				writeInterval   1; 
				locations
				('''+'''({} {} {})'''.format(probeloc[0],probeloc[1],probeloc[2])+'''
				);
				alpha		   alpha.water;
			}
		'''	

	# Field Probes
	probeLocs=''''''
	if fieldProbes=='Yes':
		for probeloc in fieldProbeLocs:

			if probeloc[4]==('u') or probeloc[4]==('U') or probeloc[4]==('V')  or probeloc[4]==('Velocity'):
				allFunctionObjects+='''
					{}'''.format(probeloc[3])+'''
				{ 
					type				probes; 
					libs				("libsampling.so"); 
					writeControl		timeStep; 
					writeInterval		1; 
					probeLocations 
					('''+'''({} {} {})'''.format(probeloc[0],probeloc[1],probeloc[2])+'''
					); 
					fields 
					( 
					U
					); 	}
				'''
			if probeloc[4]==('p') or probeloc[4]==('P') or probeloc[4]==('pressure')  or probeloc[4]==('Pressure'):
				allFunctionObjects+='''
					{}'''.format(probeloc[3])+'''
				{ 
					type				probes; 
					libs				("libsampling.so"); 
					writeControl		timeStep; 
					writeInterval		1; 
					probeLocations 
					('''+'''({} {} {})'''.format(probeloc[0],probeloc[1],probeloc[2])+'''
					); 
					fields 
					( 
					p
					); 	}
				'''
				pLocations.append([probeloc[0],probeloc[1],probeloc[2]])

	# Resultant Forces


	allFunctionObjects+='''
	interface
		{
		type		  forces;
		libs		  ("libforces.so");
		writeControl  timeStep;
		timeInterval  1;
		log		   yes;
		patches	   (interface);
		rho		   rhoInf;	 // Indicates incompressible
		log		   true;
		rhoInf		1000;		  // Redundant for incompressible'''+'''
		CofR		  ({} {} {})'''.format(resultantForceCenterOfRotation[0],resultantForceCenterOfRotation[1],resultantForceCenterOfRotation[2])+''';	// Rotation around centroid of group
		pitchAxis	 (0 1 0);
		}
	'''

	allFunctionObjects+='''
		#includeFunc  pressureSamplingPoints 
		#includeFunc  baseForces 
		#includeFunc  storyForces 
	'''

	pressureSamplingPoints='''
	/*--------------------------------*- C++ -*----------------------------------*\
	  =========				 |
	  \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox
	   \\	/   O peration	 | Website:  https://openfoam.org
		\\  /	A nd		   | Version:  10
		 \\/	 M anipulation  |
	\*----------------------------------------------------------------------------

	Description
		Writes out values of fields from cells nearest to specified locations.

	\*---------------------------------------------------------------------------*/

	type			probes;
	libs			("libsampling.so");
	writeControl	timeStep;'''+'''
	writeInterval 	{};'''.format(outputRateUQForcesAndPressures)+'''

	fields 		(p);

	probeLocations
	(
	'''
	for x in pLocations:
		pressureSamplingPoints+='''({} {} {})
		'''.format(x[0],x[1],x[2])

	pressureSamplingPoints+=''');

	// ************************************************************************* //

	'''

	with open('Fluid/system/pressureSamplingPoints','w') as f:
		f.seek(0)
		for x in pressureSamplingPoints:
			for line in x:
				f.write(line)
				f.truncate()

	baseForces='''
	/*--------------------------------*- C++ -*----------------------------------*\
	  =========				 |
	  \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox
	   \\	/   O peration	 | Website:  https://openfoam.org
		\\  /	A nd		   | Version:  10
		 \\/	 M anipulation  |
	\*---------------------------------------------------------------------------*/

	type			forces;
	libs			("libforces.so");
	patches 	(interface);
	writeControl 	timeStep;'''+'''
	writeInterval 	{};'''.format(outputRateUQForcesAndPressures)+'''
	porosity	 	no;
	log		   	yes;
	pRef	   	0.0;
	rho			rhoInf;	
	log	   	yes;		 
	rhoInf 		1000.0000;'''+'''
	CofR 		({} {} {})'''.format(resultantForceCenterOfRotation[0],resultantForceCenterOfRotation[1],resultantForceCenterOfRotation[2])+''';

	// ************************************************************************* //
	'''

	with open('Fluid/system/baseForces','w') as f:
		f.seek(0)
		for x in baseForces:
			for line in x:
				f.write(line)
				f.truncate()


	storyForces='''
	/*--------------------------------*- C++ -*----------------------------------*\
	  =========				 |
	  \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox
	   \\	/   O peration	 | Website:  https://openfoam.org
		\\  /	A nd		   | Version:  10
		 \\/	 M anipulation  |
	\*---------------------------------------------------------------------------*/

	type			forces;
	libs			("libforces.so");
	patches 	(interface);
	writeControl 	timeStep;'''+'''
	writeInterval 	{};'''.format(outputRateUQForcesAndPressures)+'''
	porosity	 	no;
	log		   	yes;
	pRef	   	0.0;
	rho			rhoInf;	
	log	   	yes;		 
	rhoInf 		1000.0000;'''+'''
	CofR 		({} {} {})'''.format(resultantForceCenterOfRotation[0],resultantForceCenterOfRotation[1],resultantForceCenterOfRotation[2])+''';

	binData
	{'''+'''
		nBin 	{};'''.format(numStories)+'''
		direction 	(0.0000 0.0000 1.0000);
		cumulative	no;
	}
	// ************************************************************************* //
	'''

	with open('Fluid/system/storyForces','w') as f:
		f.seek(0)
		for x in storyForces:
			for line in x:
				f.write(line)
				f.truncate()
				
	controlDict=['''// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
	FoamFile{
		version	 2.0;
		format	  ascii;
		class	   dictionary;
		location	"system";
		object	  controlDict;
	}
	// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

	libs
	(
		"libOpenFOAM.so"
		"libforces.so"
		"libOpenFOAM.so"
	);

	application	 olaDyMFlow;

	startFrom	   latestTime;
	''','''
	startTime	   {};'''.format(startOFSimAt),'''

	stopAt		  endTime;

	endTime		 {};'''.format(endTime+startOFSimAt),'''

	deltaT		  {};'''.format(SolutionDT),'''

	writeControl	adjustable;

	writeInterval   {};'''.format(writeDT),'''

	writeFormat	 ascii;

	writePrecision  6;

	writeCompression off;

	timeFormat	  general;

	timePrecision   12;

	runTimeModifiable {}'''.format(AdjustTimeStep),''';
	adjustTimeStep {}'''.format(AdjustTimeStep),''';

	DebugSwitches
	{
	  level	2;
	  lduMatrix 2;
	  libs 2;
	}
	OptimisationSwitches
	{
	fileHandler collated;
	maxThreadFileBufferSize 1e10; // v1712 default is 0;
	maxMasterFileBufferSize 1e10;
	}


	maxCo		   0.5;
	maxAlphaCo	  0.5;''','''
	maxDeltaT {};'''.format(SolutionDT),'''
	functions 
	{
	  // Co1
	  // {
	  //	 // Mandatory entries (unmodifiable)
	  //	 type			CourantNo;
	  //	 libs			(fieldFunctionObjects);
	  //
	  //
	  //	 // Optional (inherited) entries
	  //
	  //	 enabled		 true;
	  //	 log			 true;
	  //	 timeStart	   0;
	  //	 timeEnd		 1000;
	  //	 executeControl  timeStep;
	  //	 executeInterval 1;
	  //	 writeControl	timeStep;
	  //	 writeInterval   1;
	  // }
				preCICE_Adapter
		{
		   type preciceAdapterFunctionObject;
			libs ("libpreciceAdapterFunctionObject.so");
		}
		''',
		allFunctionObjects,
		'''
	}
	// ************************************************************************* //''']


	with open('Fluid/system/controlDict','w') as f:
		f.seek(0)
		for x in controlDict:
			for line in x:
				f.write(line)
				f.truncate()

	if fluidExists==1:
		Popen("surfaceMeshExtract -case Fluid -patches 'interface' -latestTime FluidCouplingSurface.obj", shell=True, stdout=DEVNULL).wait()
		Popen('surfaceInertia Fluid/FluidCouplingSurface.obj', shell=True, stdout=DEVNULL).wait()
		counter=0
		with open("axes.obj", "r") as f:
			for line in f:
				counter+=1
				if counter==1:
					try:
						resultantForceCenterOfRotation=line.strip('\n') #this location needs to be calculated somehow from the input surface file, or should be specified in the Hydro UQ inputs...
						resultantForceCenterOfRotation=resultantForceCenterOfRotation.strip('v')
						resultantForceCenterOfRotation=resultantForceCenterOfRotation.split(' ')
						resultantForceCenterOfRotation=resultantForceCenterOfRotation[1:]
						print(resultantForceCenterOfRotation)
					except: 
						resultantForceCenterOfRotation=[50,0,2] #this location needs to be calculated somehow from the input surface file, or should be specified in the Hydro UQ inputs...				
	else:
		# Popen("surfaceMeshExtract -case Fluid -patches 'interface' -latestTime FluidCouplingSurface.obj", shell=True, stdout=DEVNULL).wait()
		Popen('surfaceInertia Fluid/constant/triSurface/interface.stl', shell=True, stdout=DEVNULL).wait()
		counter=0
		with open("axes.obj", "r") as f:
			for line in f:
				counter+=1
				if counter==1:
					try:
						resultantForceCenterOfRotation=line.strip('\n') #this location needs to be calculated somehow from the input surface file, or should be specified in the Hydro UQ inputs...
						resultantForceCenterOfRotation=resultantForceCenterOfRotation.strip('v')
						resultantForceCenterOfRotation=resultantForceCenterOfRotation.split(' ')
						resultantForceCenterOfRotation=resultantForceCenterOfRotation[1:]
						print(resultantForceCenterOfRotation)
					except: 
						resultantForceCenterOfRotation=[50,0,2] #this location needs to be calculated somehow from the input surface file, or should be specified in the Hydro UQ inputs...	
		patchLayers='''
				interface
				{
					nSurfaceLayers 1;
				}
					'''
					
		geomSHM='''
			interface
			{
				type triSurfaceMesh;
				file "interface.stl";
			}
				''' 
				
		featExtFeats='''
				{
					file "interface.eMesh";
					level 3;
				}
				'''
		 
		refineSurfs='''	
				interface
				{
					level	(1 3);
					patchInfo
					{
						type wall;
					}
				}
				'''
		if bathExists==1:
			patchLayers+='''
					flumeFloor
					{
						nSurfaceLayers 1;
					}
						'''
						
			geomSHM+='''
					flumeFloor
				{
					type triSurfaceMesh;
					file "flumeFloor.stl";
				}
					''' 
					
			featExtFeats+='''
					{
						file "flumeFloor.eMesh";
						level 1;
					}
					'''
			 
			refineSurfs+='''	
				flumeFloor
					{
						level	(1 1);
						patchInfo
						{
							type wall;
						}
					}
					'''
					
		SHMDict=['''/*--------------------------------*- C++ -*----------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  2.4.0								 |
		|   \\  /	A nd		   | Web:	  www.OpenFOAM.org					  |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version	 2.0;
			format	  ascii;
			class	   dictionary;
			object	  snappyHexMeshDict;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

		// Which of the steps to run
		castellatedMesh true;
		snap			true;
		addLayers	   false;


		// Geometry. Definition of all surfaces. All surfaces are of class
		// searchableSurface.
		// Surfaces are used
		// - to specify refinement for any mesh cell intersecting it
		// - to specify refinement for any mesh cell inside/outside/near
		// - to 'snap' the mesh boundary to the surface
		geometry
		{
			'''+geomSHM+'''
		};

		// Settings for the castellatedMesh generation.
		castellatedMeshControls
		{
			// Refinement parameters
			// ~~~~~~~~~~~~~~~~~~~~~

			// If local number of cells is >= maxLocalCells on any processor
			// switches from from refinement followed by balancing
			// (current method) to (weighted) balancing before refinement.
			maxLocalCells 10000000;

			// Overall cell limit (approximately). Refinement will stop immediately
			// upon reaching this number so a refinement level might not complete.
			// Note that this is the number of cells before removing the part which
			// is not 'visible' from the keepPoint. The final number of cells might
			// actually be a lot less.
			maxGlobalCells 200000000;

			// The surface refinement loop might spend lots of iterations refining just a
			// few cells. This setting will cause refinement to stop if <= minimumRefine
			// are selected for refinement. Note: it will at least do one iteration
			// (unless the number of cells to refine is 0)
			minRefinementCells 10;

			// Number of buffer layers between different levels.
			// 1 means normal 2:1 refinement restriction, larger means slower
			// refinement.
			nCellsBetweenLevels 4;

			// Explicit feature edge refinement
			// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

			// Specifies a level for any cell intersected by its edges.
			// This is a featureEdgeMesh, read from constant/triSurface for now.
			features
			(
				'''+featExtFeats+'''
			);

			// Surface based refinement
			// ~~~~~~~~~~~~~~~~~~~~~~~~

			// Specifies two levels for every surface. The first is the minimum level,
			// every cell intersecting a surface gets refined up to the minimum level.
			// The second level is the maximum level. Cells that 'see' multiple
			// intersections where the intersections make an
			// angle > resolveFeatureAngle get refined up to the maximum level.

			refinementSurfaces
			{
		'''+refineSurfs+'''
			}

			// Resolve sharp angles
			resolveFeatureAngle 30;

			// Region-wise refinement
			// ~~~~~~~~~~~~~~~~~~~~~~

			// Specifies refinement level for cells in relation to a surface. One of
			// three modes
			// - distance. 'levels' specifies per distance to the surface the
			//   wanted refinement level. The distances need to be specified in
			//   descending order.
			// - inside. 'levels' is only one entry and only the level is used. All
			//   cells inside the surface get refined up to the level. The surface
			//   needs to be closed for this to be possible.
			// - outside. Same but cells outside.

			refinementRegions
			{
			}

			// Mesh selection
			// ~~~~~~~~~~~~~~

			// After refinement patches get added for all refinementSurfaces and
			// all cells intersecting the surfaces get put into these patches. The
			// section reachable from the locationInMesh is kept.
			// NOTE: This point should never be on a face, always inside a cell, even
			// after refinement.'''+''''
			locationInMesh ({} {} {});'''.format(0.01, Y/4, Z/2)+'''

			// Whether any faceZones (as specified in the refinementSurfaces)
			// are only on the boundary of corresponding cellZones or also allow
			// free-standing zone faces. Not used if there are no faceZones.
			allowFreeStandingZoneFaces true;
		}
			
		snapControls
		{
			//- Number of patch smoothing iterations before finding correspondence
			//  to surface
			nSmoothPatch 5; // or 15; 
			
			//- Relative distance for points to be attracted by surface feature point
			//  or edge. True distance is this factor times local
			//  maximum edge length.
			tolerance 0.51;  // or 0.1;
			
			//- Number of mesh displacement relaxation iterations.
			nSolveIter 10;

			//- Maximum number of snapping relaxation iterations. Should stop
			//  before upon reaching a correct mesh.
			nRelaxIter 50;

			// Feature snapping

				//- Number of feature edge snapping iterations.
				//  Leave out altogether to disable.
				nFeatureSnapIter 20;

				//- Detect (geometric only) features by sampling the surface
				//  (default=false).
				implicitFeatureSnap true;

				//- Use castellatedMeshControls::features (default = true)
				explicitFeatureSnap true;

				//- Detect points on multiple surfaces (only for explicitFeatureSnap)
				multiRegionFeatureSnap true;
		}

		// Settings for the layer addition.
		addLayersControls
		{
			// Are the thickness parameters below relative to the undistorted
			// size of the refined cell outside layer (true) or absolute sizes (false).
			relativeSizes true;

			// Per final patch (so not geometry!) the layer information
			layers
			{
		'''+patchLayers+'''
			}
			// Maximum non-orthogonality allowed; 180 disables
			maxNonOrtho 65;
			// Expansion factor for layer mesh
			expansionRatio 1.0;

			// Wanted thickness of final added cell layer. If multiple layers
			// is the thickness of the layer furthest away from the wall.
			// Relative to undistorted size of cell outside layer.
			// See relativeSizes parameter.
			finalLayerThickness 0.5;

			// Minimum thickness of cell layer. If for any reason layer
			// cannot be above minThickness do not add layer.
			// Relative to undistorted size of cell outside layer.
			minThickness 0.25;

			// If points get not extruded do nGrow layers of connected faces that are
			// also not grown. This helps convergence of the layer addition process
			// close to features.
			// Note: changed(corrected) w.r.t 17x! (didn't do anything in 17x)
			nGrow 0;

			// Advanced settings

			// When not to extrude surface. 0 is flat surface, 90 is when two faces
			// are perpendicular
			featureAngle 60;

			// At non-patched sides allow mesh to slip if extrusion direction makes
			// angle larger than slipFeatureAngle.
			slipFeatureAngle 30;

			// Maximum number of snapping relaxation iterations. Should stop
			// before upon reaching a correct mesh.
			nRelaxIter 3;

			// Number of smoothing iterations of surface normals
			nSmoothSurfaceNormals 1;

			// Number of smoothing iterations of interior mesh movement direction
			nSmoothNormals 3;

			// Smooth layer thickness over surface patches
			nSmoothThickness 10;

			// Stop layer growth on highly warped cells
			maxFaceThicknessRatio 0.5;

			// Reduce layer growth where ratio thickness to medial
			// distance is large
			maxThicknessToMedialRatio 0.3;

			// Angle used to pick up medial axis points
			// Note: changed(corrected) w.r.t 17x! 90 degrees corresponds to 130 in 17x.
			minMedianAxisAngle 90;

			// Create buffer region for new layer terminations
			nBufferCellsNoExtrude 0;

			// Overall max number of layer addition iterations. The mesher will exit
			// if it reaches this number of iterations; possibly with an illegal
			// mesh.
			nLayerIter 50;
		}

		// Generic mesh quality settings. At any undoable phase these determine
		// where to undo.
		meshQualityControls
		{
			
			maxNonOrtho	65;
			maxBoundarySkewness	20;
			maxInternalSkewness	4;
			maxConcave	80;
			minFlatness	0.5;
			minVol 1.00E-13;
			minTetQuality 1.00E-13;
			minArea	-1;
			minTwist 0.05;
			minDeterminant 0.001;
			minFaceWeight 0.05;
			minVolRatio	0.01;
			minTriangleTwist -1;
			nSmoothScale 4;
			errorReduction 0.75;

			// Advanced

			//- Number of error distribution iterations
			nSmoothScale 4;
			//- amount to scale back displacement at error points
			errorReduction 0.5;
		}

		// Settings for the snapping.
		// Merge tolerance. Is fraction of overall bounding box of initial mesh.
		// Note: the write tolerance needs to be higher than this.
		mergeTolerance 1e-6;

		// ************************************************************************* //
		''']

		with open('Fluid/system/snappyHexMeshDict','w') as f:
			f.seek(0)
			for x in SHMDict:
				for line in x:
					f.write(line)
					f.truncate()
					

		surfaceFeats='''
		interface.stl
		{
			// How to obtain raw features (extractFromFile || extractFromSurface)
			extractionMethod	extractFromSurface;

			extractFromSurfaceCoeffs
			{
				// Mark edges whose adjacent surface normals are at an angle less
				// than includedAngle as features
				// - 0  : selects no edges
				// - 180: selects all edges
				includedAngle   180;
			}

			subsetFeatures
			{
				// Keep nonManifold edges (edges with >2 connected faces)
				nonManifoldEdges	   no;

				// Keep open edges (edges with 1 connected face)
				openEdges	   yes;
			}


			// Write options

				// Write features to obj format for postprocessing
				writeObj				yes;
		}'''
		if bathExists==1:
			surfaceFeats+='''flumeFloor.stl
		{
			// How to obtain raw features (extractFromFile || extractFromSurface)
			extractionMethod	extractFromSurface;

			extractFromSurfaceCoeffs
			{
				// Mark edges whose adjacent surface normals are at an angle less
				// than includedAngle as features
				// - 0  : selects no edges
				// - 180: selects all edges
				includedAngle   180;
			}

			subsetFeatures
			{
				// Keep nonManifold edges (edges with >2 connected faces)
				nonManifoldEdges	   no;

				// Keep open edges (edges with 1 connected face)
				openEdges	   yes;
			}


			// Write options

				// Write features to obj format for postprocessing
				writeObj				yes;
		}'''
		   
		SFEDict=['''/*--------------------------------*- C++ -*----------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  5									 |
		|   \\  /	A nd		   | Web:	  www.OpenFOAM.org					  |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version	 2.0;
			format	  ascii;
			class	   dictionary;
			object	  surfaceFeatureExtractDict;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
		''',surfaceFeats,'''

		// ************************************************************************* //
		''']
		with open('Fluid/system/surfaceFeatureExtractDict','w') as f:
			f.seek(0)
			for x in SFEDict:
				for line in x:
					f.write(line)
					f.truncate()
					
					
		if waveType=="Periodic Waves":			
						
			WAVEDICT=['''/*---------------------------------------------------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  1.3								   |
		|   \\  /	A nd		   | Web:	  http://www.openfoam.org			   |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version	 2.0;
			format	  ascii;
			class	   dictionary;
			location	"constant";
			object	  waveDict;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

		waveType		regular;

		waveTheory	  StokesIII;

		genAbs		  1;

		absDir		  0.0;

		nPaddles		1;

		wavePeriod		''','''{}'''.format(periodicWaveRepeatPeriod),''';
		wavePhase		''','''{}'''.format(periodicWaveCelerity/periodicWaveRepeatPeriod),''';

		waveHeight		''','''{}'''.format(periodicWaveMagnitude),''';
		waveDir		 0.0;

		tSmooth		 0.0;

		// ************************************************************************* //
			''']

			with open('Fluid/constant/waveDict','w') as f:
				f.seek(0)
				for x in WAVEDICT:
					for line in x:
						f.write(line)
						f.truncate()
						
		# if domainSubType=="OSU LWF":
			# Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			# Popen('cp -r Fluid/0.org-OSULWF Fluid/0.org', shell=True, stdout=DEVNULL).wait()

		# elif domainSubType=="UW WASIRF":
			# Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			# Popen('cp -r Fluid/0.org-WASIRF Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			
		# elif domainSubType=="INLETOUTLET":
			# Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			# Popen('cp -r Fluid/0.org-WASIRF Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			
		# elif domainSubType=="CLOSED":
			# Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			# Popen('cp -r Fluid/0.org-CLOSED Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			

		if waveType=="Paddle Generated Waves":
			Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			Popen('cp -r Fluid/0.org-OSULWF Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			
		elif waveType=="Periodic Waves":
			Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			Popen('cp -r Fluid/0.org-WAVES Fluid/0.org', shell=True, stdout=DEVNULL).wait()
			
		else:
			if domainSubType=="CLOSED":
				Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
				Popen('cp -r Fluid/0.org-CLOSEDWASIRF Fluid/0.org', shell=True, stdout=DEVNULL).wait()	
				
			else:
				Popen('rm -rf Fluid/0.org', shell=True, stdout=DEVNULL).wait()
				Popen('cp -r Fluid/0.org-WASIRF Fluid/0.org', shell=True, stdout=DEVNULL).wait()
				if VELTH==0:
					fixedStartPatch='''
					fixedStart
						{
							type			fixedValue;
							value uniform ''','''({} 0 0);'''.format(initVelocity)+'''
						}		
					'''			
				elif VELTH==1:
					velTimeList=[]
					for y in velTimeData:
						velTimeList.append('''({} '''.format(y[0])+'''({} 0 0) )
							'''.format(y[1]))
						lastTime=y[0]
						lastVel=y[1]
					velTimeList.append('''({} '''.format(lastTime*10)+'''({} 0 0) )
							'''.format(lastVel))
					fixedStartPatch='''
										fixedStart
						{
							type			uniformFixedValue;
							uniformValue table
							(
							'''
					for veltime in velTimeList:
					
						fixedStartPatch+=veltime				
					fixedStartPatch+='''
							);
							value		$internalField;
						}		
					'''
				

				UFILE=['''/*--------------------------------*- C++ -*----------------------------------*\
				| =========				 |												 |
				| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
				|  \\	/   O peration	 | Version:  7.0								   |
				|   \\  /	A nd		   | Web:	  www.OpenFOAM.com					  |
				|	\\/	 M anipulation  |												 |
				\*---------------------------------------------------------------------------*/
				FoamFile
				{
					version	 2.0;
					format	  ascii;
					class	   volVectorField;
					location	"0";
					object	  U;
				}
				// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
				#include	  "ICfiles/initialConditions"


				dimensions	[0 1 -1 0 0 0 0];
				internalField uniform (0 0 0);

				calculatedFlowRate #eval "$Wflume*$SWL*$initialVel";

				boundaryField
				{
				 ''',fixedStartPatch,'''
					fixedEnd
					{
					type		inletOutlet;
					inletValue	$internalField;
					value		$internalField;
					}
					fixedBottom
					{
						type			noSlip;
					}   
					flumeFloor
					{
						type			noSlip;
					}
					fixedRight
					{
						type			noSlip;
					}
					fixedLeft
					{
						type			noSlip;
					}
					interface
					{
					   // type			noSlip;
						type			movingWallVelocity;
						value		  uniform (0 0 0);
					}
					fixedAtmosphere
					{
						type			pressureInletOutletVelocity;
						value		   uniform (0 0 0);
					}
					fixedStartTop
					{
						type			pressureInletOutletVelocity;
						value		   uniform (0 0 0);
					}
				}


				// ************************************************************************* //''']
				with open('Fluid/0.org/U','w') as f:
					f.seek(0)
					for x in UFILE:
						for line in x:
							f.write(line)
							f.truncate()
							

		LCOMP=X//4		
		########## BLOCK MESH EDIT ################

		if waveType=="Paddle Generated Waves": 
			blockMeshDict=['''/*--------------------------------*- C++ -*----------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  7.0								   |
		|   \\  /	A nd		   | Web:	  www.OpenFOAM.com					  |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version		 2.0;
			format		  ascii;
			class		   dictionary;
			object		  blockMeshDict;
		}

		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

		convertToMeters 1;

		// User-defined parameters
		stroke 4.0; // wavemaker piston stroke''','''
		SWL {}; // still water level'''.format(stillWaterLevel),'''
		Wflume {}; // actual flume width'''.format(Y),'''
		Lflume {}; // truncated flume length'''.format(X),'''
		Lcomp {}; // compressible mesh region length'''.format(LCOMP),'''
		zK ''','''{};'''.format(Z),'''

		// Vertex coordinates
		xI #calc "-$stroke/2.0"; // initial paddle position
		xJ #calc "$xI+$Lcomp"; // compressible mesh region end
		xK $Lflume; // flume end
		yI #calc "-$Wflume/2.0"; // right flume wall
		yJ #calc "$Wflume/2.0"; // left flume wall
		zI 0.0; // flume bottom
		zJ ''','''{};'''.format(stillWaterLevel),''' // still water level


		vertices
		(
			($xI $yI $zI) // 0
			($xI $yI $zJ) // 1
			($xI $yI $zK) // 2
			($xJ $yI $zI) // 3
			($xJ $yI $zJ) // 4
			($xJ $yI $zK) // 5
			($xK $yI $zI) // 6
			($xK $yI $zJ) // 7
			($xK $yI $zK) // 8
			($xI $yJ $zI) // 9
			($xI $yJ $zJ) // 10
			($xI $yJ $zK) // 11
			($xJ $yJ $zI) // 12
			($xJ $yJ $zJ) // 13
			($xJ $yJ $zK) // 14
			($xK $yJ $zI) // 15
			($xK $yJ $zJ) // 16
			($xK $yJ $zK) // 17
		);

		blocks		  
		(''','''
			hex (0 3 12 9  1 4 13 10) (''','''{} {} {}'''.format(LCOMP//cellSize,Y//cellSize,stillWaterLevel//cellSize),''')	simpleGrading (1 1 0.5) // compressible water-filled block
			hex (1 4 13 10 2 5 14 11) (''','''{} {} {}'''.format(LCOMP//cellSize,Y//cellSize,(Z-stillWaterLevel)//cellSize),''')	simpleGrading (1 1 2) // compressible air-filled block
			hex (3 6 15 12 4 7 16 13) (''','''{} {} {}'''.format((X-LCOMP)//cellSize,Y//cellSize,stillWaterLevel//cellSize),''')   simpleGrading (1 1 0.5) // fixed water-filled block
			hex (4 7 16 13 5 8 17 14) (''','''{} {} {}'''.format((X-LCOMP)//cellSize,Y//cellSize,(Z-stillWaterLevel)//cellSize),''')  simpleGrading (1 1 2) // fixed air-filled block''','''
		);

		edges		   
		(
		);

		boundary
		(
			paddle
			{
				type wall;
				faces
				(
					(0 1 10 9) // compressible water-filled block DM...out of the box
					(1 2 11 10) // compressi1ble air-filled block
				);
			}
			comprBottom
			{
				type wall;
				faces
				(
					(0 9 12 3) // compressible water-filled block
				);
			}
			comprRight
			{
				type wall;
				faces
				(
					(0 3 4 1) // compressible water-filled block
					(1 4 5 2) // compressible air-filled block
				);
			}
			comprLeft
			{
				type wall;
				faces
				(
					(9  10 13 12) // compressible water-filled block
					(10 11 14 13) // compressible air-filled block
				);
			}
			comprAtmosphere
			{
				type patch;
				faces
				(
					(2 5 14 11) // compressible air-filled block
				);
			}
			fixedEnd
			{
				type wall;
				faces
				(
					(6 15 16 7) // fixed water-filled block
					(7 16 17 8) // fixed air-filled block
				);
			}
			fixedBottom
			{
				type wall;
				faces
				(
					(3 12 15 6) // fixed water-filled block
				);
			}
			fixedRight
			{
				type wall;
				faces
				(
					(3 6 7 4) // fixed water-filled block
					(4 7 8 5) // fixed air-filled block
				);
			}
			fixedLeft
			{
				type wall;
				faces
				(
					(12 13 16 15) // fixed water-filled block
					(13 14 17 16) // fixed air-filled block
				);
			}
			fixedAtmosphere
			{
				type patch;
				faces
				(
					(5 8 17 14) // fixed air-filled block
				);
			}
		);

		mergePatchPairs
		(
		);
		// ************************************************************************* //'''
		]
		elif waveType=="No Waves": 
			blockMeshDict=['''/*--------------------------------*- C++ -*----------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  7.0								   |
		|   \\  /	A nd		   | Web:	  www.OpenFOAM.com					  |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version		 2.0;
			format		  ascii;
			class		   dictionary;
			object		  blockMeshDict;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
		convertToMeters 1;
		vertices
		(''','''
		   (0.0 -{} 0.0) // 0
			(0.0 {} 0.0) // 1
			(0.0 {} {}) // 2
			(0.0 -{} {}) // 3
			({} -{} 0.0) // 4
			({} {} 0.0) // 5
			({} {} {}) // 6
			({} -{} {}) // 7
		   (0.0 -{} {}) // 8
			(0.0 {} {}) // 9
			(0.0 {} {}) // 10
			(0.0 -{} {}) // 11
			({} -{} {}) // 12
			({} {} {}) // 13
			({} {} {}) // 14
			({} -{} {}) // 15	
		'''.format(Y/2,Y/2,Y/2,stillWaterLevel,Y/2,stillWaterLevel,X,Y/2,X,Y/2,X,Y/2,stillWaterLevel,X,Y/2,stillWaterLevel,Y/2,stillWaterLevel,Y/2,stillWaterLevel,Y/2,Z,Y/2,Z,X,Y/2,stillWaterLevel,X,Y/2,stillWaterLevel,X,Y/2,Z,X,Y/2,Z),''');
		blocks		  
		(
			hex (0 4 5 1 3 7 6 2) (''','''{} {} {}'''.format(xBlockCt,yBlockCt,zBlockCtSWL),''')  
			simpleGrading
		   (1 1 0.5)
			hex (8 12 13 9 11 15 14 10) (''','''{} {} {}'''.format(xBlockCt,yBlockCt,zBlockCt-zBlockCtSWL),''')  
			simpleGrading
		   (1 1 2)
		);
		edges		   
		(
		);

		boundary
		(
			fixedStart
			{
				type patch;
				faces
				(
					(3 2 1 0) // fixed air-filled block
				);
			}	
			fixedStartTop
			{
				type wall;
				faces
				(
					 (11 10 9 8) // fixed air-filled block
				);
			}
			fixedEnd
			{
				type patch;
				faces
				(
					(7 6 5 4) // fixed water-filled block
					(15 14 13 12) // fixed water-filled block
				);
			}
			fixedBottom
			{
				type wall;
				faces
				(
					(0 1 5 4) // fixed water-filled block
				);
			}
			fixedRight
			{
				type wall;
				faces
				(
					(0 4 7 3) // fixed air-filled block
					(8 12 15 11) // fixed air-filled block
				);
			}
			fixedLeft
			{
				type wall;
				faces
				(
					(1 2 6 5) // fixed air-filled block
					(9 10 14 13) // fixed air-filled block
				);
			}
			fixedAtmosphere
			{
				type patch;
				faces
				(
					(14 11 15 10) // fixed air-filled block

				);
			}
				defaultFaces1
			{
				type patch;
				faces
				(
				(2 3 7 6) // fixed air-filled block

				);
			}
					defaultFaces2
			{
				type patch;
				faces
				(
				(8 9 12 13) // fixed air-filled block

				);
			}
		);
		mergePatchPairs
		(
		(defaultFaces1 defaultFaces2)
		);
		// ************************************************************************* //
		''']
		elif waveType=="Periodic Waves": 
			blockMeshDict=['''/*--------------------------------*- C++ -*----------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  7.0								   |
		|   \\  /	A nd		   | Web:	  www.OpenFOAM.com					  |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version		 2.0;
			format		  ascii;
			class		   dictionary;
			object		  blockMeshDict;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
		convertToMeters 1;
		vertices
		(''','''
		   (0.0 -{} 0.0) // 0
			(0.0 {} 0.0) // 1
			(0.0 {} {}) // 2
			(0.0 -{} {}) // 3
			({} -{} 0.0) // 4
			({} {} 0.0) // 5
			({} {} {}) // 6
			({} -{} {}) // 7
		'''.format(Y/2,Y/2,Y/2,Z,Y/2,Z,X,Y/2,X,Y/2,X,Y/2,Z,X,Y/2,Z),''');
		blocks		  
		(
			hex (0 4 5 1 3 7 6 2) (''','''{} {} {}'''.format(xBlockCt,yBlockCt,zBlockCt),''')  
			simpleGrading
		   (1 1 1)

		);
		edges		   
		(
		);

		boundary
		(
			fixedStart
			{
				type patch;
				faces
				(
					(0 1 2 3) // fixed air-filled block
				);
			}
			fixedEnd
			{
				type patch;
				faces
				(
					(4 5 6 7) // fixed air-filled block
				);
			}
			fixedBottom
			{
				type wall;
				faces
				(
					(0 1 5 4) // fixed water-filled block
				);
			}
			fixedRight
			{
				type wall;
				faces
				(
					(0 4 7 3) // fixed air-filled block
				);
			}
			fixedLeft
			{
				type wall;
				faces
				(
					(1 2 6 5) // fixed air-filled block
				);
			}
			fixedAtmosphere
			{
				type patch;
				faces
				(
					(6 3 7 2) // fixed air-filled block
				);
			}
		);
		mergePatchPairs
		(
		);
		// ************************************************************************* //
		''']	 
		with open('Fluid/system/blockMeshDict','w') as f:
			f.seek(0)
			for x in blockMeshDict:
				for line in x:
					f.write(line)
					f.truncate()
						

		ICFILE=['''/*--------------------------------*- C++ -*----------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  5									 |
		|   \\  /	A nd		   | Web:	  www.OpenFOAM.org					  |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		// User-defined parameters
		''','''
		Wflume {};
		initialVel {};
		SWL {};
		pref {};
		// Turbulence Calcs
		// p_rghIC  #calc "$pref- (0.5*$rho*$initialVel*$initialVel)"; // [Pa] dynamic pressure, p_rgh=p-1/2*rho*U^2
		p_rghIC  {}; // [Pa] dynamic pressure, p_rgh=p-1/2*rho*U^2
		L_REF	{}; // [m]
		U_REF   {}; // [m/s]
		INTENSITY   {};
		'''.format(flumeWidth, initVelocity,stillWaterLevel,refPressure,refPressure,turbRefLength,turbReferenceVel,turbIntensity),'''
		C_mu 0.09; // [unitless] 
		kIC #eval "(3*($INTENSITY*$U_REF)*($INTENSITY*$U_REF))/2"; // [m^2/s^2] turbulent kinetic energy, TKE or k
		omegaIC #eval "(1/$L_REF)*pow($kIC,0.5)/pow($C_mu,0.25)"; // [s^-1] specific turbulence frequency, omega
		epsilonIC #eval "(1/$L_REF)*pow($kIC,1.5)*pow($C_mu,0.75)"; // [m^2/s^3] TKE dissipation rate, epsilon
		// ************************************************************************* //
		''']
		with open('Fluid/0.org/ICfiles/initialConditions','w') as f:
			f.seek(0)
			for x in ICFILE:
				for line in x:
					f.write(line)
						



		if PADDLETH==1:
			import csv
			with open(paddleDispFilePath.strip('.')+paddleDispFile,'r') as dest_f:
				data_iter = csv.reader(dest_f,
									   delimiter = ',',
									   quotechar = '"')
				data = [data for data in data_iter]
			data_array = np.asarray(data, dtype = np.float32)
			print(data_array)
			listOfWMTimes=[]
			listOfWMPos=[]
			# print('paddle disp TH', data)#
			for y in data:
				listOfWMTimes.append(y[0])
				listOfWMPos.append(y[1])
			# Export
			fid = open('Fluid/constant/wavemakerMovement.txt', 'w')

			fid.write('wavemakerType   Piston;\n')
			fid.write('tSmooth		 1.5;\n')
			fid.write('genAbs		  0;\n\n')

			fid.write('timeSeries {0}(\n'.format( len(listOfWMTimes) ))
			for t in listOfWMTimes:
				fid.write('{0}\n'.format(t))
			fid.write(');\n\n'.format( len(listOfWMTimes) ))

			fid.write('paddlePosition 1(\n')

			fid.write('{0}(\n'.format( len(listOfWMTimes) ))
			for Disp in listOfWMPos:
				fid.write('{0}\n'.format(Disp))	   
			fid.write(')\n')
			fid.write(');\n\n')


			fid.close()		

		if bathType=="Point List":
			bathpointsneg=[]
			bathpointspos=[]
			
			bathpointsneg.append([-bathXZData[0][0],-flumeWidth,bathXZData[0][1]])
			bathpointspos.append([-bathXZData[0][0],flumeWidth,bathXZData[0][1]])
				
			for xzBath in bathXZData:
				bathpointsneg.append([xzBath[0],-flumeWidth,xzBath[1]])
				bathpointspos.append([xzBath[0],flumeWidth,xzBath[1]])
				
			bathpointsneg.append([bathpointsneg[-1][0]*2,-flumeWidth,bathpointsneg[-1][2]])	
			bathpointspos.append([bathpointspos[-1][0]*2,flumeWidth,bathpointspos[-1][2]])


			trilist1=[]
			trilist2=[]
			normlist=[]

			bathSTLFile=['''solid auto2''']

			for x in range(0,len(bathpointsneg)-1):
				trilist1.append([bathpointsneg[x+1],bathpointsneg[x],bathpointspos[x]]) #tri 1
				trilist2.append([bathpointspos[x+1],bathpointsneg[x+1],bathpointspos[x]]) #tri 2
				vec3=-(np.array(bathpointspos[x+1][:]) - np.array(bathpointsneg[x+1][:]))
				vec4=-(np.array(bathpointspos[x+1][:]) - np.array(bathpointspos[x][:]))
				vec1=(np.array(bathpointspos[x][:]) - np.array(bathpointsneg[x][:]))
				vec2=(np.array(bathpointsneg[x+1][:]) - np.array(bathpointsneg[x][:]))
				
				bathSTLFile.append('''
			facet normal  {} {} {}		 
				outer loop
				   vertex {} {} {}
				   vertex {} {} {}
				   vertex {} {} {}
				endloop
			endfacet'''.format(np.cross(vec1, vec2)[0],np.cross(vec1, vec2)[1],np.cross(vec1, vec2)[2], bathpointsneg[x+1][0], bathpointsneg[x+1][1],  bathpointsneg[x+1][2], bathpointsneg[x][0],bathpointsneg[x][1],bathpointsneg[x][2], bathpointspos[x][0],bathpointspos[x][1],bathpointspos[x][2]))
				bathSTLFile.append('''
			facet normal  {} {} {}		 
				outer loop
				   vertex {} {} {}
				   vertex {} {} {}
				   vertex {} {} {}
				endloop
			endfacet'''.format(np.cross(vec3, vec4)[0],np.cross(vec3, vec4)[1],np.cross(vec3, vec4)[2], bathpointspos[x+1][0], bathpointspos[x+1][1],  bathpointspos[x+1][2], bathpointsneg[x+1][0],bathpointsneg[x+1][1],bathpointsneg[x+1][2], bathpointspos[x][0],bathpointspos[x][1],bathpointspos[x][2]))

			bathSTLFile.append('''
			endsolid
			''')


			with open('Fluid/constant/triSurface/flumeFloor.stl','w') as f:
				f.seek(0)
				for x in bathSTLFile:
					for line in x:
						f.write(line)
		else: 
			print('Surface file for bathymetry ',bathSurfaceFile)
			Popen("cp -rf "+bathSTLPath.strip('.')+bathSurfaceFile+" Fluid/constant/triSurface/flumeFloor.stl", shell=True, stdout=DEVNULL).wait()


			


		x1SetField=-10.0
		y1SetField=-1.1*Y
		z1SetField=-1.0

		x2SetField=1.1*X
		y2SetField=1.1*Y
		z2SetField=stillWaterLevel

		setFieldsDict=['''/*---------------------------------------------------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  7.0								   |
		|   \\  /	A nd		   | Web:	  http://www.openfoam.org			   |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version	 2.0;
			format	  ascii;
			class	   dictionary;
			location	"system";
			object	  setFieldsDict;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
		#include	  "../0.org/ICfiles/initialConditions"

		defaultFieldValues
		(
			volScalarFieldValue alpha.water 0
			volScalarFieldValue U 0	
		);


		regions
		(
			boxToCell
			{
				box (''','''{} {} {}'''.format(x1SetField,y1SetField,z1SetField),''') (''','''{} {} {}'''.format(x2SetField,y2SetField,z2SetField),''');

				fieldValues
				(
					volScalarFieldValue alpha.water 1
					volVectorFieldValue U ({} 0 0)'''.format(initVelocity),'''
				);
			}
		);
		''']

		with open('Fluid/system/setFieldsDict','w') as f:
			f.seek(0)
			for x in setFieldsDict:
				for line in x:
					f.write(line)

		DecompositionMethod='simple'
		 
		decomposeParDict=['''/*---------------------------------------------------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  7.0								   |
		|   \\  /	A nd		   | Web:	  http://www.openfoam.org			   |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version		 2.0;
			format		  ascii;
			location		"system";
			class		   dictionary;
			object		  decomposeParDict;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
		numberOfSubdomains  ''',''' {};
		method			   {};'''.format(DomainDecomposition,DecompositionMethod),'''

		simpleCoeffs
		{''','''
			n			   ({} {} 1);'''.format(DomainDecomposition,1),'''
			delta		   0.001;
		}

		 constraints
		{
		   patches
			{
				type	preservePatches;
				patches (interface);
				enabled true;
			}
		}
			distributed false;
			roots
			(
			);


		// ************************************************************************* //
		''']
		with open('Fluid/system/decomposeParDict','w') as f:
			f.seek(0)
			for x in decomposeParDict:
				for line in x:
					f.write(line)			  
					
		if Turbulence=='Yes':
			turbType='''simulationType  RAS;
			RAS
			{
				RASModel		kOmegaSST;
				turbulence	  on;
				printCoeffs	 on;
			}'''	   
		else:
			turbType='''simulationType  laminar;
		'''			


		turbulenceProperties=['''/*--------------------------------*- C++ -*----------------------------------*\
		| =========				 |												 |
		| \\	  /  F ield		 | OpenFOAM: The Open Source CFD Toolbox		   |
		|  \\	/   O peration	 | Version:  7.0								   |
		|   \\  /	A nd		   | Web:	  www.OpenFOAM.org					  |
		|	\\/	 M anipulation  |												 |
		\*---------------------------------------------------------------------------*/
		FoamFile
		{
			version	 2.0;
			format	  ascii;
			class	   dictionary;
			location	"constant";
			object	  turbulenceProperties;
		}
		// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

		''',turbType,'''


		// ************************************************************************* //''']
								   
		with open('Fluid/constant/turbulenceProperties','w') as f:
			f.seek(0)
			for x in turbulenceProperties:
				for line in x:
					f.write(line)  



				


					
					
					
print('				   %%%%%%%%%%%%% <<<<<<<<<<<<<<<<<<FOAMySEES CONFIGURED>>>>>>>>>>>>>>>>>> %%%%%%%%%%%%%				   ')