ops.wipe()

BaseIsolated=0

numDOF=6
rcdofs=[1,1,2,2,3,3,4,4,5,5,6,6]
FOAMySeesInstance.osi=ops.model('basic','-ndm',3,'-ndf',numDOF)

FOAMySeesInstance.coupledNodes=[]
nElem=50



numX=4
numY=40

nElem=24

#### FIBER SECTIONS ####

numSubdivY=10
numSubdivZ=10

node1=[0.602,0.00,0.0]
node2=[0.602,0.09,0.0]

beamNormal=[1., 0., 0.]

beamLength=node2[1]-node1[1]

A =0.02*0.004
I=0.02*(0.004**3)/12
Iz =0.02*(0.004**3)/12

Iy = Iz
J =  0.333

nu=0.25
E=3.5e6
G=E/(2*(1+nu))
Fy=10000e10
structuralDensity=1000

damping=0.000
z1=damping
z2=damping
f1=8.40
f2=f1*5 


matTag=1

ops.nDMaterial('ElasticIsotropic', matTag, E, nu, 0.0)





xNodeList=np.linspace(node1[0],node2[0],nElem+1)
yNodeList=np.linspace(node1[1],node2[1],nElem+1)
zNodeList=np.linspace(node1[2],node2[2],nElem+1)
nodalMass=MASS/len(xNodeList)

for nodeNum in range(0, len(xNodeList)):
    ops.node(nodeNum, xNodeList[nodeNum],yNodeList[nodeNum],zNodeList[nodeNum])

coordTransf = 'Corotational'

coordTransf='Linear'
coordTransf='PDelta'
#############################

secTag=1

ops.section('Elastic', secTag, E, A, Iz, Iy, G, J)

ops.beamIntegration('Legendre', 1, secTag, 2)

leme=0.1/(len(xNodeList)-1)
nodRotMass=(1/12)*nodalMass*(leme**2)
nodRotMass=0.
for nodeNum in range(0, len(xNodeList)):
    ops.mass(nodeNum,*[nodalMass,nodalMass,nodalMass,nodRotMass,nodRotMass,nodRotMass]) 
    
for nodeNum in range(1, len(xNodeList)):
    ops.geomTransf(coordTransf, nodeNum+100000, beamNormal[0],beamNormal[1],beamNormal[2])
    ops.element('dispBeamColumn', nodeNum, *[nodeNum-1, nodeNum], nodeNum+100000, 1) 

ops.fixY(0.0,*[1,1,1,1,1,1])
  
alphaM = 0.000 # (4*3.1415*f1*f2)*((z1*f2 - z2*f1)/(f2**2 - f1**2))               # M-prop. damping; D = alphaM*M    

betaKcurr = 00.00 # K-proportional damping;      +beatKcurr*KCurrent <- not this

betaKinit = ((z1*f2 - z2*f1)/(3.1415*(f2**2 - f1**2))) # initial-stiffness proportional damping      +beatKinit*Kini <<<<<<<<<------------------------------ use this 
betaKcomm = 0.0
ops.rayleigh(alphaM,betaKcurr, betaKinit, betaKcomm) # RAYLEIGH damping

ops.recorder('Node', '-file', 'reactionNode0.out','-time', '-node', 0, '-dof', 1,2,3,4,5,6, 'reaction')
ops.recorder('Node', '-file', 'dispNode50.out','-time', '-node', nElem, '-dof', 1,2,3,4,5,6, 'disp')

nodeRecInfoList=[['reactionBase.out',0,'reaction'],['tipDisplacement.out',nElem,'disp']]




