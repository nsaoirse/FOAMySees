# IF INSTEAD YOU WOULD LIKE TO DEFINE YOUR OWN MODEL, SPECIFY SeesModelType='USER DEFINED' AND THEN GO TO Solid/buildOpenSeesModelInThisFile.py
# to build a model using openseespy syntax. This function will be imported into the solver and your openseespy model will be built as specified.
SeesModelType='USER DEFINED'







# AUTOMESHING OPTIONS - SPECIFY THE BOUNDS, MATERIALS, SECTIONS, ELEMENTS AND NODES AND FIXITY ARE GENERATED AUTOMATICALLY
TOTAL_STRUCTURAL_MASS=2500*0.08*0.012*0.01 # THIS ONLY APPLIES IF you used FOAMySees automeshing routines... 

#SeesModelType='sdof'
SDOFPlanep1=[0.,-0.05,-0.01]
SDOFPlanep2=[0.05,-0.05,-0.01]
SDOFPlanep3=[0.05,0.05,-0.01]
SDOFPlanep4=[0.,0.05,-0.01]


#SeesModelType='solid'
loadExternalMesh=0
externalMesh='bridge.msh'


#SeesModelType='shell'
elDensity=5e-3
shellThickness=0.1
p1=[0.602,0.0,0.]
p2=[0.602,0.1,0.]
p3=[0.602,0.1,0.02]
p4=[0.602,0.0,0.02]

lc =1e-2 # element size

#### FIBER SECTIONS ####

numSubdivY=10
numSubdivZ=10

## BEAM SETTINGS ###


#SeesModelType='beam'
nElem=10


domainThickness=0.01
nNodes=nElem+1



#NodeBranchLengthX*=2


beamNormal=[-1., 0., 0.]

nElemX=-0.5
nElemY=1
nElemZ=nElem


increaseMeshResX=0.5
increaseMeshResY=0.5
increaseMeshResZ=2
structuralDensity=2500


node1=[0.006,0.00,0.005]
node2=[0.006,0.08,0.005]


  # set Poisson's ratio = 0.4

  # # Shear modulus
  # set Shear modulus   = 2.0e6

  # # Density
  # set rho             = 1000

I=0.01*(0.012**3)/12

beamLength=node2[1]-node1[1]



A = .01*0.012


#E0=SDOFStiffness*(beamLength)/(A)


elSize=1e-4

Iz = I

Iy = Iz
J =  0.333



