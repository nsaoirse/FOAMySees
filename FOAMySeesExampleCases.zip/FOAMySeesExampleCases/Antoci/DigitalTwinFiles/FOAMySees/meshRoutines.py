
import os
import concurrent.futures
import logging
import queue
import random
import subprocess
import time

import pandas as pd
import re, csv
import matplotlib
import argparse
import numpy as np
import configuration_file as config
import buildOpenSeesModelInThisFile as userModel

import math as m

import copy


import sys
import math


import meshio

import openseespy.opensees as ops
from openseespy.opensees import *

        
def meshSDOF(self):


    nElem=config.nElem
    A = config.A 
    Iz = config.Iz
    Iy =  config.Iy
    J = config.J 

    E = config.E
    G = config.G

    node1=config.node1
    node2=config.node2
    beamNormal=config.beamNormal
    
    
    xNodeList=np.linspace(node1[0],node2[0],nElem+1)
    yNodeList=np.linspace(node1[1],node2[1],nElem+1)
    zNodeList=np.linspace(node1[2],node2[2],nElem+1)
    
    for nodeNum in range(0, len(xNodeList)):
        ops.node(nodeNum, xNodeList[nodeNum],yNodeList[nodeNum],zNodeList[nodeNum])
    coordTransf = 'Corotational'

    self.time = []
     
    print(nodeBounds())
    nodeList=getNodeTags()
    self.nodeList=nodeList
    self.nodeLocs=np.zeros([len(nodeList),3])
    self.printThis=np.zeros([len(nodeList),3]) 
    nodalMass=(self.MASS/len(self.nodeLocs))
    for node in range(1,len(nodeList)):
        
        self.nodeLocs[node,:]=nodeCoord(nodeList[node])
        #  print(node,nodeCoord(nodeList[node]))
    #  print(self.nodeLocs)
    
    
    for node_num in range(len(self.nodeLocs)):
        ops.mass(self.nodeList[node_num],*[nodalMass,nodalMass,nodalMass,nodalMass,nodalMass,nodalMass])        
    for nodeNum in range(1,len(self.nodeLocs)):
        ops.geomTransf(coordTransf, nodeNum+100000, beamNormal[0],beamNormal[1],beamNormal[2])
        ops.element('elasticBeamColumn', nodeNum, nodeNum-1, nodeNum, A, E, G, J, Iy, Iz, nodeNum+100000)
        
    ###############################################
    self.finishInit()
    ###############################################

                
def meshBeam(self):

    # ##################
    # NODES
    # ##################


    
    nElem=config.nElem
    node1=config.node1
    node2=config.node2
    beamNormal=config.beamNormal
    
    numSubdivY=self.config.numSubdivY
    numSubdivZ=self.config.numSubdivZ

    
    
    xNodeList=np.linspace(node1[0],node2[0],nElem+1)
    yNodeList=np.linspace(node1[1],node2[1],nElem+1)
    zNodeList=np.linspace(node1[2],node2[2],nElem+1)
    nodalMass=self.MASS/len(xNodeList)
    
    for nodeNum in range(0, len(xNodeList)):
        ops.node(nodeNum, xNodeList[nodeNum],yNodeList[nodeNum],zNodeList[nodeNum])
    
    # ##################
    # ELEMENTS
    # ##################
    
    

    A = config.A 
    Iz = config.Iz
    Iy =  config.Iy
    J = config.J 

    E = config.E
    nu=config.nu
    G = config.G
    matTag=1
    K=E*G/(3*(3*G - E))
    sig0=50e6
    sigInf=100e6
    delta=0.1
    H=0.5
    
    sigmaY=config.sigmaY
    H_iso=config.H_iso
    H_kin=config.H_kin

    
    #ops.uniaxialMaterial('Elastic', matTag, E) 
    #ops.uniaxialMaterial('ElasticPP', matTag, E, 0.05)
    
    #ops.uniaxialMaterial('ElasticMultiLinear', matTag, 0.0, '-strain', *[-0.3,-0.2,-0.1,0,0.1,0.2,0.3], '-stress', *[-0.3*E,-0.2*E,-0.1*E,0,0.1*E,0.2*E,0.3*E])
    
    #ops.uniaxialMaterial('MultiLinear', matTag, *[0.001, E*0.001, 0.2, E*0.15])
    
    ops.uniaxialMaterial('Hardening', matTag, E, sigmaY, H_iso, H_kin)
    #ops.nDMaterial('ElasticIsotropic', matTag, E, nu, 1000.0)
    #ops.nDMaterial('J2Plasticity', matTag, K, G, sig0, sigInf, delta, H)
    
    coordTransf = 'Corotational'
    coordTransf='PDelta'
    #############################
    self.time = []
     
    print(nodeBounds())
    nodeList=getNodeTags()
    self.nodeList=nodeList
    self.nodeLocs=np.zeros([len(nodeList),3])
    self.printThis=np.zeros([len(nodeList),3]) 
    nodalMass=self.MASS/len(self.nodeLocs)
    secTag=1
    matTag=1
    
    #ops.section('Elastic', secTag, E, A, Iz, Iy, G, J)
    
    ops.section('Fiber', secTag, '-GJ', G*J)

    ops.patch('rect', matTag, 2,12, *[-0.005,-0.006], *[0.005,0.006])
    
    for node in range(1,len(nodeList)):
        
        self.nodeLocs[node,:]=nodeCoord(nodeList[node])
    
    ops.beamIntegration('Legendre', 1, secTag, 2)
    
    leme=10/(len(xNodeList)-1)
    nodRotMass=0 #(1/12)*nodalMass*(leme**2)
    for node_num in range(len(self.nodeLocs)):
        ops.mass(self.nodeList[node_num],*[nodalMass,nodalMass,nodalMass,nodRotMass,nodRotMass,nodRotMass])        
    for nodeNum in range(1,len(self.nodeLocs)):
        ops.geomTransf(coordTransf, nodeNum+100000, beamNormal[0],beamNormal[1],beamNormal[2])
        #ops.element('dispBeamColumn', nodeNum, *[nodeNum-1, nodeNum], nodeNum+100000, 1) #, '-cMass', '-mass', mass=0.0)
        #ops.element('elasticBeamColumn', nodeNum, nodeNum-1, nodeNum, A, E, G, J, Iy, Iz, nodeNum+100000)
        ops.element('nonlinearBeamColumn', nodeNum, *[nodeNum-1, nodeNum],5,secTag,nodeNum+100000,'-iter', 1)
    
        
    ###############################################
    self.finishInit()
    ###############################################
    
def meshShell(self):
    
    ###################################
    ## Define Material
    ###################################

    # Define PSUMAT and convert it to plane stress material
    # nDMaterial('PlasticDamageConcretePlaneStress', matTag, E, nu, ft, fc, <beta, Ap, An, Bn>)
    # nDMaterial('PlaneStressUserMaterial', matTag, nstatevs, nprops, fc, ft, fcu, epsc0, epscu, epstu, stc)
    E = config.E
    nu = config.nu
    structuralDensity=config.structuralDensity
    matTag=1
    secTag=1
    
    nDMaterial('ElasticIsotropic', matTag, E, nu, structuralDensity)

           ##########################
    # ELEMENTS 
    ##########################

    ShellType = "ShellNLDKGQ"
    
    ops.section('PlateFiber', secTag, matTag, config.shellThickness)
    # Define LayeredShell sections. section('LayeredShell',sectionNo,numberOfLayers,layer1Mat,layer1Thickness,...,layerNMat,layerNThickness)
    # ops.section('LayeredShell',secTag,8,1,0.0005,1,0.0005,1,0.0005,1,0.0005,1,0.0005,1,0.0005,1,0.0005,1,0.0005)

    
    gmsh.initialize(sys.argv)

    gmsh.model.add("t2")

    p1=config.p1
    p2=config.p2
    p3=config.p3
    p4=config.p4

    lc=config.lc

    gmsh.model.geo.addPoint(p1[0], p1[1], p1[2], lc, 1000000)
    gmsh.model.geo.addPoint(p2[0], p2[1], p2[2], lc, 2000000)
    gmsh.model.geo.addPoint(p3[0], p3[1], p3[2], lc, 3000000)
    gmsh.model.geo.addPoint(p4[0], p4[1], p4[2], lc, 4000000)
    gmsh.model.geo.addLine(1000000, 2000000, 1)
    gmsh.model.geo.addLine(3000000, 2000000, 2)
    gmsh.model.geo.addLine(3000000, 4000000, 3)
    gmsh.model.geo.addLine(4000000, 1000000, 4)
    gmsh.model.geo.addCurveLoop([4, 1, -2, 3], 1)

    gmsh.model.geo.addPlaneSurface([1], 1)
    gmsh.model.geo.synchronize()
    gmsh.model.addPhysicalGroup(0, [1, 2, 4], 5)
    ps = gmsh.model.addPhysicalGroup(2, [1])
    gmsh.model.setPhysicalName(2, ps, "My surface")


    # ov2 = gmsh.model.geo.extrude(([(2, 1)]), 0, 0, 1)


    gmsh.model.geo.synchronize()

    gmsh.option.setNumber("Mesh.Smoothing", 10)
    gmsh.option.setNumber("Mesh.RecombineAll", 1)
    

    gmsh.model.mesh.generate(2)

    print(gmsh.model.mesh)
    gmsh.write("t2.msh")
    
    gmsh.finalize()

    mesh = gmshparser.parse("t2.msh")
    print(mesh)

    for entity in mesh.get_node_entities():
        for nodes in entity.get_nodes():
            nid = nodes.get_tag()
            # if nid>4:
            ncoords = nodes.get_coordinates()
            print("Node id = %s, node coordinates = %s" % (nid, ncoords))
            ops.node(nid, ncoords[0], ncoords[1], ncoords[2])
            




    for entity in mesh.get_element_entities():
    #    eltype = entity.get_element_type()
    #    print("Element type: %s" % eltype)
        for elements in entity.get_elements():
            elid = elements.get_tag()
            elcon = elements.get_connectivity()
            if len(elcon)>1:
                print("Element id = %s, connectivity = %s" % (elid, elcon))
                ops.element(ShellType,elid,elcon[0],elcon[1],elcon[2],elcon[3],1)

    self.fixitySet()
    
    # ops.rigidLink('bar', 1, 2)
    # ops.rigidLink('bar', 1, 3)
    # ops.rigidLink('bar', 1, 4)
    # ops.rigidLink('bar', 1, 5)
    ops.constraints('Transformation')
    # ops.geomTransf('Corotational', 101, *[0,0,1])

    #############################
    self.time = []
     
    print(nodeBounds())
    nodeList=getNodeTags()
    self.nodeList=nodeList
    self.nodeLocs=np.zeros([len(nodeList),3])

    self.lastForces=np.zeros([len(self.nodeLocs),3])

    nodalMass=(self.MASS/len(self.nodeLocs))
    for node in range(1,len(nodeList)):
        self.nodeLocs[node,:]=nodeCoord(nodeList[node])

    
    self.NodalReactionForces=np.zeros([len(self.nodeLocs),3])

    self.force=np.zeros([len(self.nodeLocs),3])
    self.displacement=np.zeros([len(self.nodeLocs),3])
    self.printThis=[0.,0.,0.]

    self.outputs = {new_list: {
        "x_disp": [0.0],
        "x_accel": [0.0],
        "x_vel": [0.0],
        "x_force": [0.0],
        "y_disp": [0.0],
        "y_accel": [0.0],
        "y_vel": [0.0],
        "y_force": [0.0],
        "z_disp": [0.0],
        "z_accel": [0.0],
        "z_vel": [0.0],
        "z_force": [0.0]
        } for new_list in range(len(self.nodeLocs))}
    
    print('OpenSees Model Initialized...')
    
def meshSolid(self):

 
    ###################################
    ## Define Material
    ###################################

    # Define PSUMAT and convert it to plane stress material
    # nDMaterial('PlasticDamageConcretePlaneStress', matTag, E, nu, ft, fc, <beta, Ap, An, Bn>)
    # nDMaterial('PlaneStressUserMaterial', matTag, nstatevs, nprops, fc, ft, fcu, epsc0, epscu, epstu, stc)
    E = config.E
    nu = config.nu
    structuralDensity=config.structuralDensity
    wipe()
    matTag=1
    secTag=1
    nDMaterial('ElasticIsotropic', matTag, E, nu, structuralDensity)
    pi = 3.1415
    b1, b2, b3 =[0.,0.,0.]

    
    model('basic','-ndm',3,'-ndf',3)

    ###################################
    ## Define Material
    ###################################

    # Define PSUMAT and convert it to plane stress material
    # nDMaterial('PlasticDamageConcretePlaneStress', matTag, E, nu, ft, fc, <beta, Ap, An, Bn>)
    # nDMaterial('PlaneStressUserMaterial', matTag, nstatevs, nprops, fc, ft, fcu, epsc0, epscu, epstu, stc)


    # Convert rebar material to plane stress/plate rebar 
    # Angle 0 is for vertical rebar and 90 is for horizontal rebar


    noRefineSteps=0
    
    if self.config.loadExternalMesh==1:
        mesh = gmshparser.parse(self.config.externalMesh)
    else:

        lc = self.config.elDensity

        # Before using any functions in the Python API, Gmsh must be initialized:
        gmsh.initialize()

        # Next we add a new model named "t1" (if gmsh.model.add() is not called a new
        # unnamed model will be created on the fly, if necessary):
        gmsh.model.add("t3")

        # Copied from t1.py...
        xmin=0.25
        xmax=0.6
        ymin=0.19
        ymax=0.21
        zLoc=-0.01

        gmsh.model.geo.addPoint(xmin, ymin, zLoc, lc, 1)
        gmsh.model.geo.addPoint(xmax, ymin, zLoc, lc, 2)
        gmsh.model.geo.addPoint(xmax, ymax, zLoc, lc, 3)
        gmsh.model.geo.addPoint(xmin, ymax, zLoc, lc, 4)


        gmsh.model.geo.addLine(1, 2, 1)
        gmsh.model.geo.addLine(3, 2, 2)
        gmsh.model.geo.addLine(3, 4, 3)
        gmsh.model.geo.addLine(4, 1, 4)
        gmsh.model.geo.addCurveLoop([4, 1, -2, 3], 1)
        gmsh.model.geo.addPlaneSurface([1], 1)

        gmsh.model.geo.synchronize()
        gmsh.model.addPhysicalGroup(1, [1, 2, 4], 5)
        ps = gmsh.model.addPhysicalGroup(2, [1])
        gmsh.model.setPhysicalName(2, ps, "My surface")

        gmsh.option.setNumber("Mesh.RecombineAll",ps)

        blockLayers=[2,2]
        blockLayerEndPts=[0.5,1]
        gmsh.option.setNumber("Mesh.Algorithm", 8)  # Frontal-Delaunay for 2D meshes
        extrusionX=0
        extrusionY=0
        extrusionZ = 0.02

        extrusions=[extrusionX,extrusionY,extrusionZ]

        SurfDim=2

        SurfTag=1

        gmsh.model.geo.extrude([(SurfDim, SurfTag)],extrusions[0],extrusions[1],extrusions[2], blockLayers, blockLayerEndPts, True)



        gmsh.model.geo.synchronize()
        gmsh.model.addPhysicalGroup(3,[1],1)
        gmsh.model.mesh.generate(3)



        for x in range(noRefineSteps):
            gmsh.model.mesh.refine()


        gmsh.model.mesh.removeDuplicateNodes()


        gmsh.model.geo.synchronize()
        gmsh.write("t3.msh")

            
        gmsh.finalize()
        mesh = gmshparser.parse("t3.msh")
    #print(mesh)

    for entity in mesh.get_node_entities():
        for nodes in entity.get_nodes():
            nid = nodes.get_tag()
            
            # if nid>4:
            ncoords = nodes.get_coordinates()
            #print("Node id = %s, node coordinates = %s" % (nid, ncoords))
            ops.node(nid, ncoords[0], ncoords[1], ncoords[2])
             
    for entity in mesh.get_element_entities():
        eltype = entity.get_element_type()
        if eltype != 5: 
            pass
        else:    
            print("Element type: %s" % eltype)
            for elements in entity.get_elements():
                elid = elements.get_tag()
                elcon = elements.get_connectivity()
                if len(elcon)>6:
                    #print("Element id = %s, connectivity = %s" % (elid, elcon))
                    #ops.element('stdBrick',elid,*elcon,1,*[0.0,0.0,0.0])
                    ops.element('SSPbrick',elid,*elcon,1,*[0.0,0.0,0.0])

    
    self.fixitySet()

    nodeList=getNodeTags()
    nodeLocs=np.zeros([len(nodeList),3])
    for node in range(1,len(nodeList)):
        
        nodeLocs[node,:]=nodeCoord(nodeList[node])
        
            # ops.rigidLink('bar', 1, 2)
    # ops.rigidLink('bar', 1, 3)
    # ops.rigidLink('bar', 1, 4)
    # ops.rigidLink('bar', 1, 5)
    ops.constraints('Transformation')
    # ops.geomTransf('Corotational', 101, *[0,0,1])

    #############################
    self.time = []
     
    print(nodeBounds())
    nodeList=getNodeTags()
    self.nodeList=nodeList
    self.nodeLocs=np.zeros([len(nodeList),3])

    self.lastForces=np.zeros([len(self.nodeLocs),3])

    nodalMass=(self.MASS/len(self.nodeLocs))
    for node in range(1,len(nodeList)):
        
        self.nodeLocs[node,:]=nodeCoord(nodeList[node])
        #  print(node,nodeCoord(nodeList[node]))
    #  print(self.nodeLocs)
    for node_num in range(len(self.nodeLocs)):
       ops.mass(self.nodeList[node_num],*[nodalMass,nodalMass,nodalMass,nodalMass,nodalMass,nodalMass])        
    
    self.NodalReactionForces=np.zeros([len(self.nodeLocs),3])

    self.force=np.zeros([len(self.nodeLocs),3])
    self.displacement=np.zeros([len(self.nodeLocs),3])
    self.printThis=[0.,0.,0.]

    self.outputs = {new_list: {
        "x_disp": [0.0],
        "x_accel": [0.0],
        "x_vel": [0.0],
        "x_force": [0.0],
        "y_disp": [0.0],
        "y_accel": [0.0],
        "y_vel": [0.0],
        "y_force": [0.0],
        "z_disp": [0.0],
        "z_accel": [0.0],
        "z_vel": [0.0],
        "z_force": [0.0]
        } for new_list in range(len(self.nodeLocs))}
        
    filename="SeesVTKOutput"
    if not os.path.exists(filename):
        os.makedirs(filename)

    res=['disp','vel','accel','incrDisp','reaction','unbalancedLoad']
    if self.rank==0:
        ops.recorder('PVD', filename,*res, '-dT', self.config.VTKOutputRate)
    
    print('OpenSees Model Initialized...')