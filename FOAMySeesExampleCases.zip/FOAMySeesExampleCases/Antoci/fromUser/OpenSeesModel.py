ops.wipe()

BaseIsolated=0

numDOF=6
rcdofs=[1,1,2,2,3,3,4,4,5,5,6,6]
FOAMySeesInstance.osi=ops.model('basic','-ndm',3,'-ndf',numDOF)

FOAMySeesInstance.coupledNodes=[]

numX=4
numY=40

ops.wipe()
    
BaseIsolated=0

numDOF=6

FOAMySeesInstance.osi=ops.model('basic','-ndm',3,'-ndf',numDOF)

FOAMySeesInstance.coupledNodes=[]

inchesSubmerged=2
# 2d SpecimenWidth=0.01406/0.0254
SpecimenWidth=2.75 # 3d

SpecimenLength=20

Xmin=0.1025
Ymax=0.01/2
Ymin=-Ymax
Ztop=0.15
Zbot=0.01

cornerLocs=[[Xmin,Ymin,Zbot],[Xmin,Ymax,Zbot],[Xmin,Ymax,Ztop],[Xmin,Ymin,Ztop]]

#eleType='shell'
eleType='ShellNLDKGQ'
eleArgs=[100]

matTag=625

h=0.005   

nu=0.29


E=10e6 #steel panel 
G=E/(2*(1+nu))
K=E/(3*(1-(2*nu)))
sig0=220000000
sigInf=100e7
H=0.5
rho=2900   
delta=1

totalMass=1100*0.01*0.005*0.079

ops.nDMaterial('ElasticIsotropic', matTag, E, nu)
#ops.nDMaterial('J2Plasticity', matTag, K, G, sig0, sigInf, delta, H)
ops.nDMaterial('PlateFiber', matTag+1,matTag)

secTag=100



#ops.section('ElasticMembranePlateSection', secTag, E, nu, h)

# mats=[[matTag, h/3], [matTag, h/3], [matTag, h/3]]
# ops.section('LayeredShell', secTag, 3, *mats)

ops.section('PlateFiber', secTag, matTag+1, h)

coooords=[1,cornerLocs[0][0],cornerLocs[0][1],cornerLocs[0][2],2,cornerLocs[1][0],cornerLocs[1][1],cornerLocs[1][2],3,cornerLocs[2][0],cornerLocs[2][1],cornerLocs[2][2],4, cornerLocs[3][0],cornerLocs[3][1],cornerLocs[3][2]]

# block2D(numX, numY, startNode, startEle, eleType, *eleArgs, *crds)
eleType='shell'
eleArgs=[100]
startNode=1
startEle=1

ops.block2D(numX, numY, startNode, startEle, eleType, *eleArgs, *coooords)
SlabNodes=np.linspace(startNode,startNode+((numX+1)*(numY+1))-1,((numX+1)*(numY+1)))

nodeMss=totalMass/len(SlabNodes)

for nodeNum in SlabNodes:
    FOAMySeesInstance.coupledNodes.append(int(nodeNum))
    ops.mass(nodeNum,*[nodeMss,nodeMss,nodeMss,0,0,0])


ops.fixZ(Ztop,*[1,1,1,1,1,1])

            
z1=0.0250
z2=0.0250
f1=0.1
f2=1500000

alphaM = 0.000 # (4*3.1415*f1*f2)*((z1*f2 - z2*f1)/(f2**2 - f1**2))               # M-prop. damping; D = alphaM*M    

betaKcurr = 00.00 # K-proportional damping;      +beatKcurr*KCurrent <- not this

betaKinit = ((z1*f2 - z2*f1)/(3.1415*(f2**2 - f1**2))) # initial-stiffness proportional damping      +beatKinit*Kini <<<<<<<<<------------------------------ use this 
betaKcomm = 0.0
ops.rayleigh(alphaM,betaKcurr, betaKinit, betaKcomm) # RAYLEIGH damping


nodeRecInfoList=[['reactionBase1.out',201,'reaction'],['reactionBase2.out',202,'reaction'],['reactionBase3.out',203,'reaction'],['reactionBase4.out',204,'reaction'],['reactionBase5.out',205,'reaction'],['tipDisplacementLeft.out',1,'disp'],['tipDisplacementRight.out',5,'disp']]


