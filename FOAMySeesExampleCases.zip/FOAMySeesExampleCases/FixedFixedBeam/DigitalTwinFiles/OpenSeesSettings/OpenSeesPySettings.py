
ApplyGravity='yes'
g=[0,0,-9.81]
OpenSeesconvergenceTol=1e-6

Test=["NormUnbalance",1e-4,100]
Integration=["Newton",0.5,0.25]
Algorithm="KrylovNewton"
OpenSeesSystem='BandGen'
OpenSeesConstraints='Transformation'
Numberer='RCM'
OSndm=3
OSndf=6
Analysis=["Transient","-numSubLevels",2,"-numSubSteps",10]



