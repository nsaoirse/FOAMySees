import openseespy.opensees as ops
def applyGM(startTime):
	pass
	
def removeGM():
	pass
