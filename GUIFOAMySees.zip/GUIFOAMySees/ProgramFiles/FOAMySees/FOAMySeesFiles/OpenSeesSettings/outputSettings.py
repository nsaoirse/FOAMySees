#OpenFOAM Write Frequency
writeDT=0.1 # seconds

#OpenSeesPy Write Frequency
SeesVTKOUTRate=0.1 # seconds


# OpenFOAM Surface Output
interfaceSurfaceOutput=1 #ok 

# OpenFOAM Cut Surface Output
cutSurfaceOutput=1 # ok 
cutSurfaceLocsDirsFields=[[[1.44780004025, -0.0101600000635, 0.0976745234802],[1, 0, 0],['p','U']],[[1.44780004025, -0.0101600000635, 0.1976745234802],[0, 0, 1],['p','U']]]

# Free Surface VTK
freeSurfOut=1 # ok


# Free Surface Probes
freeSurfProbes=1 # ok
freeSurfProbeLocs=[[1,0,0.5],[2,0,0.5],[3,0,0.5]]

# Velocity Probes
velocityProbes=1 # ok
velocityProbeLocs=[[1,0,0.5],[2,0,0.5],[3,0,0.5]]

# Pressure Probes
pressureProbes=1 # ok
pressureProbeLocs=[[1,0,0.5],[2,0,0.5],[3,0,0.5]]

# Resultant Forces
resultantForces=1 # ok
resultantForceCenterOfRotation=[1.44780004025, -0.0101600000635, 0.0976745234802]

# OpenFOAM Displacement Probes
ofDispProbe=1 # ok 
ofDispProbeLocs=[[1.44780004025, -0.0101600000635, 0.0976745234802],[1.44780004025, -0.0101600000635, 0.1976745234802]]


# OpenSeesPy Displacement Probes
osDispProbe=1 # ok 
osDispProbeLocs=[[1.44780004025, -0.0101600000635, 0.0976745234802],[1.44780004025, -0.0101600000635, 0.1976745234802]]



