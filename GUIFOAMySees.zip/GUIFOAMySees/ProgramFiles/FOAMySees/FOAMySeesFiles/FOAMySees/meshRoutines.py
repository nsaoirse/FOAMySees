from dependencies import *
def makeEQDOFs(self,tolerance=1e-2):


	allNodeLocs=[]

	allNodes=ops.getNodeTags()
	allNodes=set(allNodes)
	allNodes=list(allNodes)
	for node in allNodes:
	    allNodeLocs.append(ops.nodeCoord(node))
	allNodeLocs=np.array(allNodeLocs) 

	# creating zeroDOF connections for everything within a particular tolerance of one another

	for node in allNodes:
		nearNode=np.where((np.abs(allNodeLocs - ops.nodeCoord(node)[:])<=[tolerance,tolerance,tolerance]).all(axis=1))[:]
		nearNode=nearNode[0][:]
		print(nearNode)
		#try:
		for nearNodeCurr in nearNode:
			rNodeTag=allNodes[nearNodeCurr]
			cNodeTag=node
			print('cNodeTag',cNodeTag)
			print('rNodeTag',rNodeTag)
			if cNodeTag==rNodeTag:
				pass
			elif cNodeTag in rNodes:
				pass	
			elif cNodeTag in cNodes:
				pass
			else:
				if rNodeTag in cNodes:
					pass
		# 	            cNodeTag1=cNodeTag
		# 	            cNodeTag=rNodeTag
		# 	            rNodeTag=cNodeTag1
		# 	            print('cNodeTag',cNodeTag)
		# 	            print('rNodeTag',rNodeTag)
		# 	            if rNodeTag in cNodes:
		# 	                pass
		# 	            else:
		#             		if constraintType=='EQDOF': 
		#             			ops.equalDOF(rNodeTag, cNodeTag, *dofs)
		#             		elif constraintType=='RIGIDLINK':	
		#             			ops.rigidLink('beam', rNodeTag, cNodeTag)
		#             		elif constraintType=='EQDOFMIXED':
		#             			ops.equalDOF_Mixed(rNodeTag, cNodeTag, numDOF, *rcdofs)
		#             		print('Found a node with matching location, creating EQ DOF connection')
		#             		cNodes.append(cNodeTag)
				else:
					if constraintType=='EQDOF': 
						ops.equalDOF(rNodeTag, cNodeTag, *dofs)
					elif constraintType=='RIGIDLINK':	
						ops.rigidLink('beam', rNodeTag, cNodeTag)
					elif constraintType=='EQDOFMIXED':
						ops.equalDOF_Mixed(rNodeTag, cNodeTag, numDOF, *rcdofs)
					print('Found a node with matching location, creating EQ DOF connection')
					cNodes.append(cNodeTag)
		    #except:
		    #    pass
