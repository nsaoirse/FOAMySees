Tol=1e-3
maxNumIter = 10
#ops.pattern('UniformExcitation', IDloadTag, GMdirection, '-accel', 2) 
ops.constraints('Transformation')
ops.numberer('Plain')
ops.system('BandGeneral')
ops.test('EnergyIncr', Tol, maxNumIter)
ops.algorithm('ModifiedNewton')
NewmarkGamma = 0.5
NewmarkBeta = 0.25
ops.integrator('Newmark', NewmarkGamma, NewmarkBeta)
ops.analysis('VariableTransient')
DtAnalysis = 0.001
TmaxAnalysis = 10
Nsteps =  int(TmaxAnalysis/ DtAnalysis)
ok=1
# for i in test:
ops.algorithm('KrylovNewton')

# ok = ops.analyze(Nsteps, DtAnalysis,DtAnalysis/10,DtAnalysis,1)	

# ops.wipeAnalysis
