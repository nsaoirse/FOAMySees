def buildOpenSeesModelFile(openSeesPyScript,writeHere,copyInputFilesTo='./userInputs/'):
    print('Building OpenSees Model')
    print(openSeesPyScript)


    with open(copyInputFilesTo+openSeesPyScript,'r') as file:
        lines = [line.rstrip() for line in file]
        
    with open(writeHere+'/buildOpenSeesModelInThisFile.py','w') as f:
        f.seek(0)
        f.write('''from dependencies import *
def defineYourModelWithinThisFunctionUsingOpenSeesPySyntax(FOAMySeesInstance):
''')

                
        for line2 in lines:
            f.write('\t')
            f.write(line2)
            f.write('\n')
                 
        f.write('''
        try:
            FOAMySeesInstance.coupledNodes=coupledNodes
        except:
            pass
        try: 
            FOAMySeesInstance.nodeRecInfoList=nodeRecInfoList
        except:
            FOAMySeesInstance.nodeRecInfoList=[]
    ''')
        f.write('\n')   
        f.truncate()


