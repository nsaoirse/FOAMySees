from dependencies  import *
def runGravity(self):
	print('preliminaryAnalysis.runGravity()')	
	pass

def runPreliminaryAnalysis(self):
	print('preliminaryAnalysis.runPreliminaryAnalysis()')
	pass
