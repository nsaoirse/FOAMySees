couplingConvergenceTol=1e-5	
implicit=1
mapType='nearest-neighbor' #'rbf-thin-plate-splines'
couplingDataAccelerationMethod="IQN-ILS" #"Constant","Aitken","IQN-ILS","IQN-IMVJ","Broyden"
initialRelaxationFactor=0.6
maximumCouplingIterations=100
outputDataFromCouplingIterations="no"
couplingIterationOutputDataFrequency=100

