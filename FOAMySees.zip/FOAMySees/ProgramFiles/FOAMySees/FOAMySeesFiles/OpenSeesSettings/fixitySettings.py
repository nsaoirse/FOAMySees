fixXat=[0.0]

fixYat=[0.0]
fixZat=[0.0]
fixX='no'
fixY='no'
fixZ='yes'

fixXatFixity=[1,1,1,1,1,1]
fixYatFixity=[1,1,1,1,1,1]
fixZatFixity=[1,1,1,1,1,1]