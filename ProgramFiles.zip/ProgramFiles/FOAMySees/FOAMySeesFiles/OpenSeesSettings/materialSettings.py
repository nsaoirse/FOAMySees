
structuralDensity=2500
nu=0.3
E=1000000 #10^7 dyne or 1MPa


G=E/(2*(1+nu))

sigmaY=1E5
H_iso=0.15 
H_kin=0.25

E0=E

E2=E0

E=E0
