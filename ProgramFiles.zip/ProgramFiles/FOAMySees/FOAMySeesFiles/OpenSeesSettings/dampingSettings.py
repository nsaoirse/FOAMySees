
damping=0.0
z1=damping
z2=damping

f1=0.01
f2=10
