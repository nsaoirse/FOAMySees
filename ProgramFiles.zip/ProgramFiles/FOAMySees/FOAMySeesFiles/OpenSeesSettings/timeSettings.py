DecompositionMethod="scotch"
DomainDecomposition=40


############ BOTH OpenFOAM and OpenSees


SolutionDT=1e-6
runPrelim='yes'

# openSees...
SeesSubSteps=1

# OpenFOAM...
AdjustTimeStep='no'
startOFSimAt=0.0
endTime=10


SimDuration=endTime






